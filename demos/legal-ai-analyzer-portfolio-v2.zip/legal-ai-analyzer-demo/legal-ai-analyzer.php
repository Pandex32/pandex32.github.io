<?php
/**
 * Plugin Name: Legal AI Analyzer (AI Engine)
 * Description: AI-powered legal document scanner, contract generator, risk analyzer, missing clause detector, and key date extractor — powered by AI Engine.
 * Version: 1.2.0
 * Author: Dylan Osei-Afriyie
 * License: GPL v2 or later
 * Text Domain: legal-ai-analyzer
 */

if (!defined('ABSPATH')) exit;

define('LAA_VERSION', '1.3.0');
define('LAA_PLUGIN_DIR', plugin_dir_path(__FILE__));
define('LAA_PLUGIN_URL', plugin_dir_url(__FILE__));

require_once LAA_PLUGIN_DIR . 'includes/class-pdf-extractor.php';
require_once LAA_PLUGIN_DIR . 'includes/class-pdf-generator.php';
require_once LAA_PLUGIN_DIR . 'includes/generate-form-fields.php';

// Activation 
register_activation_hook(__FILE__, 'laa_activate');
function laa_activate() {
 global $wpdb;
 $table_name = $wpdb->prefix . 'laa_analyses';
 $charset_collate = $wpdb->get_charset_collate();
 $sql = "CREATE TABLE IF NOT EXISTS $table_name (
 id mediumint(9) NOT NULL AUTO_INCREMENT,
 user_id bigint(20) NOT NULL,
 document_name varchar(255) NOT NULL,
 analysis_type varchar(50) NOT NULL,
 result longtext NOT NULL,
 created_at datetime DEFAULT CURRENT_TIMESTAMP,
 PRIMARY KEY (id)
 ) $charset_collate;";
 require_once ABSPATH . 'wp-admin/includes/upgrade.php';
 dbDelta($sql);
 add_option('laa_ai_engine_model', '');
 add_option('laa_max_tokens', 4000);
}

register_deactivation_hook(__FILE__, 'laa_deactivate');
function laa_deactivate() {}

// Check AI Engine is active 
add_action('plugins_loaded', 'laa_check_ai_engine');
function laa_check_ai_engine() {
 if (!function_exists('mwai_get_core') && !class_exists('Meow_MWAI_Core')) {
 add_action('admin_notices', function () {
 echo '<div class="notice notice-error"><p><strong>Legal AI Analyzer:</strong> The <a href="https://wordpress.org/plugins/ai-engine/" target="_blank">AI Engine plugin</a> must be installed and activated.</p></div>';
 });
 }
}

// Admin menu 
add_action('admin_menu', 'laa_admin_menu');
function laa_admin_menu() {
 add_menu_page('Legal AI Analyzer', 'Legal AI', 'manage_options', 'legal-ai-analyzer', 'laa_admin_page', 'dashicons-shield', 30);
 add_submenu_page('legal-ai-analyzer', 'Settings', 'Settings', 'manage_options', 'laa-settings', 'laa_settings_page');
 add_submenu_page('legal-ai-analyzer', 'History', 'History', 'manage_options', 'laa-history', 'laa_history_page');
}

// Enqueue admin assets 
add_action('admin_enqueue_scripts', 'laa_enqueue_admin_assets');
function laa_enqueue_admin_assets($hook) {
 if (strpos($hook, 'legal-ai') === false) return;
 wp_enqueue_style('laa-admin-style', LAA_PLUGIN_URL . 'assets/css/admin.css', [], LAA_VERSION);
 wp_enqueue_script('laa-admin-script', LAA_PLUGIN_URL . 'assets/js/admin.js', ['jquery'], LAA_VERSION, true);
 wp_enqueue_script('laa-generate-form', LAA_PLUGIN_URL . 'assets/js/generate-form.js', ['jquery'], LAA_VERSION, true);
 wp_enqueue_style('laa-signature-style', LAA_PLUGIN_URL . 'assets/css/signature.css', [], LAA_VERSION);
 wp_enqueue_script('laa-signature-script', LAA_PLUGIN_URL . 'assets/js/signature.js', ['jquery', 'laa-frontend-script'], LAA_VERSION, true);
 wp_localize_script('laa-admin-script', 'laaData', [
 'ajaxUrl' => admin_url('admin-ajax.php'),
 'nonce' => wp_create_nonce('laa_nonce'),
 ]);
}

// Enqueue frontend assets 
add_action('wp_enqueue_scripts', 'laa_enqueue_frontend_assets');
function laa_enqueue_frontend_assets() {
 global $post;
 if (is_a($post, 'WP_Post') && (has_shortcode($post->post_content, 'legal_ai_analyzer') || has_shortcode($post->post_content, 'laa_dashboard_home'))) {
 wp_enqueue_style('laa-frontend-style', LAA_PLUGIN_URL . 'assets/css/frontend.css', [], LAA_VERSION);
 wp_enqueue_script('laa-frontend-script', LAA_PLUGIN_URL . 'assets/js/frontend.js', ['jquery'], LAA_VERSION, true);
 wp_enqueue_script('laa-generate-form', LAA_PLUGIN_URL . 'assets/js/generate-form.js', ['jquery'], LAA_VERSION, true);
 wp_enqueue_style('laa-signature-style', LAA_PLUGIN_URL . 'assets/css/signature.css', [], LAA_VERSION);
 wp_enqueue_script('laa-signature-script', LAA_PLUGIN_URL . 'assets/js/signature.js', ['jquery', 'laa-frontend-script'], LAA_VERSION, true);
 wp_localize_script('laa-frontend-script', 'laaData', [
 'ajaxUrl' => admin_url('admin-ajax.php'),
 'nonce' => wp_create_nonce('laa_nonce'),
 'isLoggedIn' => is_user_logged_in(),
 'categories' => laa_get_categories(),
 ]);
 }
}

// Register settings 
add_action('admin_init', 'laa_register_settings');
function laa_register_settings() {
 register_setting('laa_settings_group', 'laa_ai_engine_model', ['sanitize_callback' => 'sanitize_text_field']);
 register_setting('laa_settings_group', 'laa_max_tokens', ['sanitize_callback' => 'absint']);
}

// AJAX: Extract PDF 
add_action('wp_ajax_laa_extract_pdf', 'laa_extract_pdf');
add_action('wp_ajax_nopriv_laa_extract_pdf', 'laa_extract_pdf');
function laa_extract_pdf() {
 check_ajax_referer('laa_nonce', 'nonce');

 if (empty($_FILES['pdf_file'])) {
 wp_send_json_error(['message' => 'No file was uploaded.']);
 }

 $file = $_FILES['pdf_file'];

 if ($file['error'] !== UPLOAD_ERR_OK) {
 $errors = [
 UPLOAD_ERR_INI_SIZE => 'File exceeds server upload limit.',
 UPLOAD_ERR_FORM_SIZE => 'File exceeds form size limit.',
 UPLOAD_ERR_PARTIAL => 'File was only partially uploaded.',
 UPLOAD_ERR_NO_FILE => 'No file was uploaded.',
 UPLOAD_ERR_NO_TMP_DIR => 'Server missing temp folder.',
 UPLOAD_ERR_CANT_WRITE => 'Failed to write file to disk.',
 ];
 wp_send_json_error(['message' => $errors[$file['error']] ?? 'Unknown upload error.']);
 }

 if ($file['size'] > 10 * 1024 * 1024) {
 wp_send_json_error(['message' => 'PDF file must be under 10MB.']);
 }

 $finfo = finfo_open(FILEINFO_MIME_TYPE);
 $mimetype = finfo_file($finfo, $file['tmp_name']);
 finfo_close($finfo);

 $ext = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
 if (!in_array($mimetype, ['application/pdf', 'application/x-pdf', 'application/acrobat']) && $ext !== 'pdf') {
 wp_send_json_error(['message' => 'Only PDF files are allowed.']);
 }

 $text = LAA_PDF_Extractor::extract($file['tmp_name']);

 if (is_wp_error($text)) {
 wp_send_json_error(['message' => $text->get_error_message()]);
 }

 $truncated = false;
 if (strlen($text) > 80000) {
 $text = substr($text, 0, 80000);
 $truncated = true;
 }

 wp_send_json_success([
 'text' => $text,
 'filename' => sanitize_file_name($file['name']),
 'summary' => LAA_PDF_Extractor::get_summary($text),
 'truncated' => $truncated,
 ]);
}

// AJAX: Analyze document 
add_action('wp_ajax_laa_analyze_document', 'laa_analyze_document');
add_action('wp_ajax_nopriv_laa_analyze_document', 'laa_analyze_document');
function laa_analyze_document() {
 check_ajax_referer('laa_nonce', 'nonce');

 $analysis_type = sanitize_text_field($_POST['analysis_type'] ?? 'analyze');
 $document_text = sanitize_textarea_field($_POST['document_text'] ?? '');
 $contract_type = sanitize_text_field($_POST['contract_type'] ?? '');
 $contract_details = sanitize_textarea_field($_POST['contract_details'] ?? '');

 if (empty($document_text) && $analysis_type !== 'generate') {
 wp_send_json_error(['message' => 'No document text provided.']);
 }

 $prompt = laa_build_prompt($analysis_type, $document_text, $contract_type, $contract_details);
 $result = laa_run_ai_engine_query($prompt);

 // Portfolio Demo Mode fallback: if AI Engine is not installed or has no API key configured, return realistic British legal analysis
 if (is_wp_error($result)) {
 $result = laa_generate_demo_fallback($analysis_type, $document_text, $contract_type, $contract_details);
 }

 global $wpdb;
 $wpdb->insert($wpdb->prefix . 'laa_analyses', [
 'user_id' => get_current_user_id(),
 'document_name' => substr($document_text ?: $contract_details, 0, 100) . '...',
 'analysis_type' => $analysis_type,
 'result' => $result,
 ]);

 wp_send_json_success(['result' => $result, 'type' => $analysis_type]);
}

// AJAX: Delete history 
add_action('wp_ajax_laa_delete_history', 'laa_delete_history');
function laa_delete_history() {
 check_ajax_referer('laa_nonce', 'nonce');
 if (!current_user_can('manage_options')) wp_send_json_error();
 $id = absint($_POST['id']);
 global $wpdb;
 $wpdb->delete($wpdb->prefix . 'laa_analyses', ['id' => $id]);
 wp_send_json_success();
}

// AI Engine query 
function laa_run_ai_engine_query($prompt) {
 try {
 global $mwai;
 if (!isset($mwai) || !is_object($mwai)) {
 if (function_exists('mwai_get_core')) {
 $core = mwai_get_core();
 if (!$core) {
 return new WP_Error('ai_engine_missing', 'AI Engine core not available.');
 }
 } else {
 return new WP_Error('ai_engine_missing', 'AI Engine is not installed or activated.');
 }
 }
 $params = ['maxTokens' => (int) get_option('laa_max_tokens', 4000), 'scope' => 'legal-ai-analyzer'];
 $model = get_option('laa_ai_engine_model', '');
 if (!empty($model)) $params['model'] = $model;
 $result = $mwai->simpleTextQuery($prompt, $params);
 if (empty($result)) return new WP_Error('empty_response', 'AI Engine returned an empty response.');
 return $result;
 } catch (Exception $e) {
 return new WP_Error('ai_engine_error', 'AI Engine error: ' . $e->getMessage());
 }
}

// Build prompts 
function laa_build_prompt($type, $text, $contract_type = '', $details = '') {
 $system = "You are a highly experienced legal analyst and contract solicitor. Provide detailed, accurate, well-structured legal document analysis formatted in clean HTML. You must write entirely in British English — use British spelling throughout (e.g. analyse not analyze, organise not organize, recognised not recognized, licence not license (noun), authorisation not authorization, summarise not summarize, labelled not labeled, favour not favor, behaviour not behavior, practise not practice (verb), defence not defense, offence not offense, programme not program, cheque not check (financial), colour not color).";

 switch ($type) {
 case 'analyze':
 return "$system\n\nAnalyse the following legal document comprehensively using this exact HTML structure:\n\n<div class='laa-section laa-overview'><h3> Document Overview</h3>[Document type, parties involved, purpose, governing jurisdiction]</div>\n<div class='laa-section laa-risks'><h3> Risk Assessment</h3>[Legal risks with HIGH/MEDIUM/LOW severity, described in British English]</div>\n<div class='laa-section laa-missing'><h3> Missing Clauses</h3>[Absent standard clauses with priority levels]</div>\n<div class='laa-section laa-dates'><h3> Key Dates & Deadlines</h3>[Important dates in a table]</div>\n<div class='laa-section laa-recommendations'><h3> Recommendations</h3>[Numbered actionable improvements]</div>\n\nDOCUMENT:\n$text";

 case 'risks':
 return "$system\n\nPerform a detailed risk analysis of this contract. For each risk provide: name, severity (HIGH/MEDIUM/LOW), description, potential legal or financial impact, and mitigation recommendation. Use British legal terminology throughout. Format as structured HTML with colour-coded severity badges.\n\nCONTRACT:\n$text";

 case 'missing':
 return "$system\n\nIdentify ALL missing standard clauses in this contract. For each missing clause provide: clause name, why it is legally important under English law, suggested template language, and priority (Critical/Important/Optional). Use British legal terminology and spelling throughout. Format as structured HTML.\n\nCONTRACT:\n$text";

 case 'dates':
 return "$system\n\nExtract ALL dates, deadlines, and time-sensitive obligations from this document. Organise into: absolute dates, relative deadlines, recurring obligations, expiration dates, and notice periods. Format as an HTML table with columns: Date/Period | Obligation | Responsible Party | Consequences if Missed.\n\nDOCUMENT:\n$text";

 case 'generate':
 return "$system\n\nDraft a comprehensive, legally sound $contract_type agreement based on the following requirements:\n\n$details\n\nThe agreement should be governed by English law unless otherwise specified. Include all standard sections: parties header, recitals, definitions, core terms and conditions, payment terms, intellectual property ownership, confidentiality obligations, representations and warranties, indemnification, limitation of liability, termination clauses, dispute resolution, governing law and jurisdiction, severability, entire agreement, variation procedure. End the document with EXACTLY these two placeholder lines and nothing else after them:\\n\\n[PARTY_A_SIGNATURE_BLOCK]\\n[PARTY_B_SIGNATURE_BLOCK]\\n\\nDo NOT include any other signature section, blank underscores, or Party A / Party B lines with blanks. Use ONLY those two placeholders — the plugin will replace them with real signatures. Format as a professional HTML legal document with clearly numbered clauses and [PLACEHOLDER] fields marked in brackets.";

 case 'summary':
 return "$system\n\nCreate a plain-English executive summary of the following legal document, suitable for someone without legal training. Include: what this document is and why it matters, key obligations for each party, important rights granted or waived, financial terms explained simply, key dates and deadlines, what happens if obligations are not met, and an overall fairness assessment (Favourable / Balanced / Unfavourable — and for whom). Use clear, straightforward British English. Avoid legal jargon where possible. Format as structured HTML.\n\nDOCUMENT:\n$text";

 default:
 return "$system\n\nAnalyse this legal document and provide a structured summary in British English:\n\n$text";
 }
}

// Page callbacks 
function laa_admin_page() { include LAA_PLUGIN_DIR . 'templates/admin-main.php'; }
function laa_settings_page() { include LAA_PLUGIN_DIR . 'templates/admin-settings.php'; }
function laa_history_page() { include LAA_PLUGIN_DIR . 'templates/admin-history.php'; }

// Shortcode 
add_shortcode('legal_ai_analyzer', 'laa_shortcode');
function laa_shortcode($atts) {
 ob_start();
 include LAA_PLUGIN_DIR . 'templates/frontend.php';
 return ob_get_clean();
}

// Available document categories 
function laa_get_categories() {
 return [
 'Contract Analysis',
 'Risk Assessment',
 'Missing Clauses',
 'Key Dates',
 'Contract Draft',
 'Plain Summary',
 'Employment',
 'NDA / Confidentiality',
 'Property / Lease',
 'Intellectual Property',
 'Corporate',
 'Other',
 ];
}

// AJAX: Check if a save already exists for this document name 
add_action('wp_ajax_laa_check_existing_save', 'laa_check_existing_save');
function laa_check_existing_save() {
 check_ajax_referer('laa_nonce', 'nonce');
 if (!is_user_logged_in()) wp_send_json_error();

 $user_id = get_current_user_id();
 $doc_name = sanitize_text_field($_POST['doc_name'] ?? '');

 if (empty($doc_name)) wp_send_json_error();

 // Look for an existing WPDM package by this user with this title
 $existing = get_posts([
 'post_type' => 'wpdmpro',
 'author' => $user_id,
 'post_status' => 'publish',
 'posts_per_page' => 1,
 'title' => $doc_name,
 'meta_query' => [[
 'key' => '_laa_owner_user_id',
 'value' => $user_id,
 ]],
 ]);

 if (!empty($existing)) {
 wp_send_json_success(['package_id' => $existing[0]->ID]);
 } else {
 wp_send_json_error(['message' => 'No existing save found.']);
 }
}

// AJAX: Save analysis result as PDF to WP Download Manager 
add_action('wp_ajax_laa_save_to_dashboard', 'laa_save_to_dashboard');
function laa_save_to_dashboard() {
 check_ajax_referer('laa_nonce', 'nonce');

 if (!is_user_logged_in()) {
 wp_send_json_error(['message' => 'You must be logged in to save documents to your dashboard.']);
 }

 $user_id = get_current_user_id();
 $html_result = wp_kses_post($_POST['html_result'] ?? '');
 $doc_name = sanitize_text_field($_POST['doc_name'] ?? 'Legal Analysis');
 $category = sanitize_text_field($_POST['category'] ?? 'Contract Analysis');
 $analysis_type = sanitize_text_field($_POST['analysis_type'] ?? 'analyze');
 $existing_id = absint($_POST['existing_id'] ?? 0);
 $save_mode = sanitize_text_field($_POST['save_mode'] ?? 'new'); // new | append | replace

 if (empty($html_result)) {
 wp_send_json_error(['message' => 'No analysis result to save.']);
 }

 if (!function_exists('wpdm_create_package') && !class_exists('WPDM_Package')) {
 wp_send_json_error(['message' => 'WP Download Manager is not active. Please install and activate it.']);
 }

 // If appending, prepend existing PDF content
 if ($save_mode === 'append' && $existing_id) {
 $existing_html = get_post_meta($existing_id, '_laa_html_content', true);
 if ($existing_html) {
 $html_result = $existing_html . '<hr style="margin:30px 0;border:none;border-top:2px solid #dde3ea;">' . $html_result;
 }
 // Delete old PDF file/attachment
 $old_attach_ids = get_post_meta($existing_id, '_laa_attachment_ids', true);
 if ($old_attach_ids) {
 foreach ((array)$old_attach_ids as $aid) {
 wp_delete_attachment($aid, true);
 }
 }
 }

 // Generate PDF
 $pdf_path = LAA_PDF_Generator::generate($html_result, $doc_name, $category, $analysis_type, $user_id);
 if (is_wp_error($pdf_path)) {
 wp_send_json_error(['message' => 'PDF generation failed: ' . $pdf_path->get_error_message()]);
 }

 // Register as media attachment
 $attachment = LAA_PDF_Generator::register_as_attachment($pdf_path, $doc_name, $user_id);
 if (is_wp_error($attachment)) {
 wp_send_json_error(['message' => 'Could not register file: ' . $attachment->get_error_message()]);
 }

 $timestamp = current_time('d M Y, H:i');
 $package_title = $doc_name;

 if ($save_mode === 'replace' && $existing_id) {
 // Update existing package
 wp_update_post(['ID' => $existing_id, 'post_title' => $package_title]);
 $package_id = $existing_id;
 // Delete old attachment
 $old_attach_ids = get_post_meta($existing_id, '_laa_attachment_ids', true);
 if ($old_attach_ids) {
 foreach ((array)$old_attach_ids as $aid) {
 wp_delete_attachment($aid, true);
 }
 }
 } elseif ($save_mode === 'append' && $existing_id) {
 $package_id = $existing_id;
 } else {
 // Create new package
 $package_id = wp_insert_post([
 'post_title' => $package_title,
 'post_status' => 'publish',
 'post_author' => $user_id,
 'post_type' => 'wpdmpro',
 ]);
 if (is_wp_error($package_id)) {
 wp_send_json_error(['message' => 'Could not create dashboard entry: ' . $package_id->get_error_message()]);
 }
 }

 // Update WPDM package meta
 update_post_meta($package_id, '__wpdm_package', serialize(['att_ids' => [$attachment['attachment_id']]]));
 update_post_meta($package_id, '__wpdm_files', [$attachment['filename']]);
 update_post_meta($package_id, '__wpdm_link_label', $package_title);
 update_post_meta($package_id, '__wpdm_access', ['logged_in_users']);
 update_post_meta($package_id, '__wpdm_categories', [$category]);
 update_post_meta($package_id, '_laa_owner_user_id', $user_id);
 update_post_meta($package_id, '_laa_analysis_type', $analysis_type);
 update_post_meta($package_id, '_laa_saved_at', current_time('mysql'));
 update_post_meta($package_id, '_laa_html_content', $html_result); // stored for future appends
 update_post_meta($package_id, '_laa_attachment_ids', [$attachment['attachment_id']]);

 if (function_exists('wpdm_add_user_upload')) {
 wpdm_add_user_upload($user_id, $package_id);
 }

 wp_send_json_success([
 'message' => 'Saved successfully.',
 'package_id' => $package_id,
 'package_url' => get_permalink($package_id),
 'filename' => basename($pdf_path),
 'timestamp' => $timestamp,
 ]);
}

// AJAX: Save signed contract 
add_action('wp_ajax_laa_save_signed_contract', 'laa_save_signed_contract');
add_action('wp_ajax_nopriv_laa_save_signed_contract', 'laa_save_signed_contract');
function laa_save_signed_contract() {
 check_ajax_referer('laa_nonce', 'nonce');

 $contract_html = wp_kses_post($_POST['contract_html'] ?? '');
 $signature_a = sanitize_text_field($_POST['signature_a'] ?? ''); // base64 PNG
 $signature_b = sanitize_text_field($_POST['signature_b'] ?? '');
 $name_a = sanitize_text_field($_POST['name_a'] ?? '');
 $name_b = sanitize_text_field($_POST['name_b'] ?? '');
 $email_a = sanitize_email($_POST['email_a'] ?? '');
 $email_b = sanitize_email($_POST['email_b'] ?? '');
 $contract_type = sanitize_text_field($_POST['contract_type'] ?? 'Contract');
 $signed_date = current_time('d F Y');
 $signed_time = current_time('H:i');

 if (empty($contract_html)) {
 wp_send_json_error(['message' => 'No contract content provided.']);
 }
 if (empty($name_a) || empty($name_b)) {
 wp_send_json_error(['message' => 'Both party names are required.']);
 }
 if (empty($signature_a) || empty($signature_b)) {
 wp_send_json_error(['message' => 'Both parties must sign before saving.']);
 }
 if (!function_exists('wpdm_create_package') && !class_exists('WPDM_Package')) {
 wp_send_json_error(['message' => 'WP Download Manager is not active.']);
 }

 // Step 1: Strip any AI-generated signature sections from the contract 
 // The AI sometimes generates blank signature lines like:
 // Party A: ________________ or [PARTY_A_SIGNATURE_BLOCK]
 // We remove ALL of these so we can insert real signatures in the right place.

 $clean_html = $contract_html;

 // Remove common AI-generated blank signature patterns
 $strip_patterns = [
 // Underscored blanks: Party A: __________ / Signature: ___________
 '/(<[^>]*>)*\s*(?:Party\s*[AB]|Signator(?:y|ies)|Authorised\s+Signator(?:y|ies)|Signed\s+(?:by|for)|Signature|Name|Print(?:ed)\s+Name)\s*:?\s*_{3,}.*?(?=<|\n|$)/im',
 // X lines: ________________________
 '/^\s*_{5,}\s*$/m',
 // Bracketed signature placeholders (any variant)
 '/\[\s*(?:PARTY_[AB]_SIGNATURE_BLOCK|SIGNATURE_BLOCK|SIGN_HERE|INSERT_SIGNATURE)\s*\]/i',
 // Whole signature section headings with blank content below
 '/(<(?:h[1-6]|p|div)[^>]*>\s*(?:IN WITNESS|SIGNATURES?|EXECUTION|SIGNED AND DELIVERED|SIGNED BY THE PARTIES)\s*<\/(?:h[1-6]|p|div)>)(\s*<[^>]+>\s*)*\s*(?=<(?:h[1-6]|p|div)>|$)/is',
 ];

 foreach ($strip_patterns as $pattern) {
 $cleaned = preg_replace($pattern, '', $clean_html);
 if ($cleaned !== null) $clean_html = $cleaned;
 }

 // Step 2: Build the real signature block HTML 
 $sig_block = '
 <div style="margin-top:48px;padding-top:28px;border-top:2px solid #1a1a2e;page-break-inside:avoid;">
 <h3 style="text-align:center;font-size:15px;letter-spacing:0.12em;text-transform:uppercase;margin-bottom:8px;color:#1a1a2e;">Signatures</h3>
 <p style="text-align:center;font-size:11px;color:#666;margin-bottom:28px;font-style:italic;">
 By signing below, both parties confirm they have read, understood, and agree to the terms of this ' . esc_html($contract_type) . '.
 </p>
 <table style="width:100%;border-collapse:collapse;">
 <tr>
 <td style="width:47%;vertical-align:top;padding-right:16px;border-right:1px solid #ddd;">
 <p style="font-size:9px;font-weight:700;text-transform:uppercase;letter-spacing:0.1em;color:#b8933f;margin-bottom:6px;">Party A</p>
 <p style="font-weight:600;font-size:13px;margin-bottom:2px;color:#1a1a2e;">' . esc_html($name_a) . '</p>
 ' . ($email_a ? '<p style="font-size:10px;color:#888;margin-bottom:12px;">' . esc_html($email_a) . '</p>' : '<p style="margin-bottom:12px;"></p>') . '
 <img src="' . esc_attr($signature_a) . '" style="max-width:200px;height:65px;display:block;margin-bottom:4px;" alt="Signature of ' . esc_attr($name_a) . '" />
 <div style="height:1px;background:#1a1a2e;max-width:200px;margin-bottom:6px;"></div>
 <p style="font-size:9px;color:#aaa;line-height:1.7;">
 Signed: ' . esc_html($signed_date) . ' at ' . esc_html($signed_time) . '<br>
 IP: ' . esc_html($_SERVER['REMOTE_ADDR'] ?? 'recorded') . '
 </p>
 </td>
 <td style="width:6%;"></td>
 <td style="width:47%;vertical-align:top;padding-left:16px;">
 <p style="font-size:9px;font-weight:700;text-transform:uppercase;letter-spacing:0.1em;color:#b8933f;margin-bottom:6px;">Party B</p>
 <p style="font-weight:600;font-size:13px;margin-bottom:2px;color:#1a1a2e;">' . esc_html($name_b) . '</p>
 ' . ($email_b ? '<p style="font-size:10px;color:#888;margin-bottom:12px;">' . esc_html($email_b) . '</p>' : '<p style="margin-bottom:12px;"></p>') . '
 <img src="' . esc_attr($signature_b) . '" style="max-width:200px;height:65px;display:block;margin-bottom:4px;" alt="Signature of ' . esc_attr($name_b) . '" />
 <div style="height:1px;background:#1a1a2e;max-width:200px;margin-bottom:6px;"></div>
 <p style="font-size:9px;color:#aaa;line-height:1.7;">
 Signed: ' . esc_html($signed_date) . ' at ' . esc_html($signed_time) . '<br>
 IP: ' . esc_html($_SERVER['REMOTE_ADDR'] ?? 'recorded') . '
 </p>
 </td>
 </tr>
 </table>
 <div style="margin-top:28px;padding:10px 14px;background:#f9f7f3;border:1px solid #ede9e0;border-radius:3px;font-size:9px;color:#aaa;line-height:1.8;text-align:center;">
 This document was electronically signed via Legal AI Analyzer on ' . esc_html($signed_date . ' at ' . $signed_time) . '.
 Governed by the Electronic Communications Act 2000 and eIDAS Regulation.
 </div>
 </div>';

 // Step 3: Place signatures — use placeholder if present, else append 
 $placeholder_a = '[PARTY_A_SIGNATURE_BLOCK]';
 $placeholder_b = '[PARTY_B_SIGNATURE_BLOCK]';

 if (strpos($clean_html, $placeholder_a) !== false || strpos($clean_html, $placeholder_b) !== false) {
 // Placeholders found — replace them with the combined sig block
 // Remove both placeholders and insert the full block where the first one was
 $combined = $sig_block;
 $clean_html = str_replace($placeholder_b, '', $clean_html);
 $clean_html = str_replace($placeholder_a, $combined, $clean_html);
 } else {
 // No placeholders — append to end (safe fallback)
 $clean_html = rtrim($clean_html) . $sig_block;
 }

 $full_html = $clean_html;

 // Determine user — use logged in user, or find by email
 $user_id = get_current_user_id();
 if (!$user_id && $email_a) {
 $user = get_user_by('email', $email_a);
 if ($user) $user_id = $user->ID;
 }
 if (!$user_id) $user_id = 1; // fallback to admin

 $doc_name = $contract_type . ' — ' . $name_a . ' & ' . $name_b . ' (' . $signed_date . ')';
 $category = 'Signed Contracts';

 // Generate PDF using existing PDF generator
 $pdf_path = LAA_PDF_Generator::generate($full_html, $doc_name, $category, 'signed', $user_id);
 if (is_wp_error($pdf_path)) {
 wp_send_json_error(['message' => 'PDF generation failed: ' . $pdf_path->get_error_message()]);
 }

 // Register as media attachment
 $attachment = LAA_PDF_Generator::register_as_attachment($pdf_path, $doc_name, $user_id);
 if (is_wp_error($attachment)) {
 wp_send_json_error(['message' => 'Could not register file: ' . $attachment->get_error_message()]);
 }

 // Save to WP Download Manager
 $package_id = wp_insert_post([
 'post_title' => $doc_name,
 'post_status' => 'publish',
 'post_author' => $user_id,
 'post_type' => 'wpdmpro',
 ]);

 if (is_wp_error($package_id)) {
 wp_send_json_error(['message' => 'Could not save to dashboard: ' . $package_id->get_error_message()]);
 }

 update_post_meta($package_id, '__wpdm_package', serialize(['att_ids' => [$attachment['attachment_id']]]));
 update_post_meta($package_id, '__wpdm_files', [$attachment['filename']]);
 update_post_meta($package_id, '__wpdm_link_label', $doc_name);
 update_post_meta($package_id, '__wpdm_access', ['logged_in_users']);
 update_post_meta($package_id, '__wpdm_categories', [$category]);
 update_post_meta($package_id, '_laa_owner_user_id', $user_id);
 update_post_meta($package_id, '_laa_analysis_type', 'signed');
 update_post_meta($package_id, '_laa_saved_at', current_time('mysql'));
 update_post_meta($package_id, '_laa_signed_by_a', $name_a);
 update_post_meta($package_id, '_laa_signed_by_b', $name_b);
 update_post_meta($package_id, '_laa_attachment_ids', [$attachment['attachment_id']]);

 if (function_exists('wpdm_add_user_upload')) {
 wpdm_add_user_upload($user_id, $package_id);
 }

 // Save to history table
 global $wpdb;
 $wpdb->insert($wpdb->prefix . 'laa_analyses', [
 'user_id' => $user_id,
 'document_name' => $doc_name,
 'analysis_type' => 'signed',
 'result' => 'Signed by: ' . $name_a . ' & ' . $name_b . ' on ' . $signed_date,
 ]);

 // Email notification to both parties
 $subject = 'Your signed ' . $contract_type . ' is ready';
 $message = "Hello,\n\nYour signed contract has been saved and is available to download from your account.\n\n";
 $message .= "Contract: " . $doc_name . "\n";
 $message .= "Signed: " . $signed_date . " at " . $signed_time . "\n\n";
 $message .= "Log in to download your copy: " . home_url('/my-account') . "\n\n";
 $message .= "This is an automated message from Legal AI Analyzer.";

 if ($email_a) wp_mail($email_a, $subject, $message);
 if ($email_b && $email_b !== $email_a) wp_mail($email_b, $subject, $message);

 wp_send_json_success([
 'message' => 'Contract signed and saved successfully.',
 'package_id' => $package_id,
 'package_url' => get_permalink($package_id),
 'filename' => basename($pdf_path),
 'doc_name' => $doc_name,
 ]);
}

// Template helper: Frontend PDF uploader 
if (!function_exists('laa_render_frontend_pdf_uploader')) {
function laa_render_frontend_pdf_uploader($tab_id) { ?>
<div class="laa-f-pdf-zone" id="f-pdf-zone-<?php echo esc_attr($tab_id); ?>" data-tab="f-<?php echo esc_attr($tab_id); ?>">
 <input type="file" accept=".pdf,application/pdf" class="laa-f-pdf-input" id="f-pdf-input-<?php echo esc_attr($tab_id); ?>" style="display:none;" />
 <div class="laa-f-pdf-drop" id="f-pdf-drop-<?php echo esc_attr($tab_id); ?>">
 <span></span>
 <p>Drag &amp; drop PDF here</p>
 <button type="button" class="laa-f-pdf-browse" data-input="f-pdf-input-<?php echo esc_attr($tab_id); ?>">Browse PDF</button>
 <small>PDF only · Max 10MB</small>
 </div>
 <div class="laa-f-pdf-uploading" id="f-pdf-loading-<?php echo esc_attr($tab_id); ?>" style="display:none;">
 <div class="laa-f-spinner" style="width:20px;height:20px;border-width:2px;display:inline-block;margin-right:8px;"></div>
 Extracting text...
 </div>
 <div class="laa-f-pdf-done" id="f-pdf-status-<?php echo esc_attr($tab_id); ?>" style="display:none;">
 <strong id="f-pdf-filename-<?php echo esc_attr($tab_id); ?>"></strong>
 <span id="f-pdf-summary-<?php echo esc_attr($tab_id); ?>" style="color:#6b7280;font-size:12px;margin-left:8px;"></span>
 <button type="button" class="laa-f-pdf-remove" data-tab="<?php echo esc_attr($tab_id); ?>" style="margin-left:12px;background:none;border:none;color:#800020;cursor:pointer;font-size:12px;"> Remove</button>
 </div>
</div>
<?php }
}

// Template helper: Admin PDF uploader 
if (!function_exists('laa_render_pdf_uploader')) {
function laa_render_pdf_uploader($tab_id) { ?>
<div class="laa-pdf-zone" id="pdf-zone-<?php echo esc_attr($tab_id); ?>" data-tab="<?php echo esc_attr($tab_id); ?>">
 <input type="file" accept=".pdf,application/pdf" class="laa-pdf-input" id="pdf-input-<?php echo esc_attr($tab_id); ?>" style="display:none;" />
 <div class="laa-pdf-drop" id="pdf-drop-<?php echo esc_attr($tab_id); ?>">
 <span class="laa-pdf-drop-icon"></span>
 <p class="laa-pdf-drop-label">Drag &amp; drop your PDF here</p>
 <button type="button" class="laa-pdf-browse-btn" data-input="pdf-input-<?php echo esc_attr($tab_id); ?>">Browse PDF</button>
 <p class="laa-pdf-drop-hint">PDF only · Max 10MB · Text-based PDFs only (not scanned images)</p>
 </div>
 <div class="laa-pdf-uploading" id="pdf-loading-<?php echo esc_attr($tab_id); ?>" style="display:none;">
 <div class="laa-pdf-spinner"></div>
 <span>Extracting text from PDF...</span>
 </div>
 <div class="laa-pdf-done" id="pdf-status-<?php echo esc_attr($tab_id); ?>" style="display:none;">
 <div class="laa-pdf-done-inner">
 <span class="laa-pdf-done-icon"></span>
 <div>
 <strong id="pdf-filename-<?php echo esc_attr($tab_id); ?>"></strong>
 <span id="pdf-filesummary-<?php echo esc_attr($tab_id); ?>"></span>
 </div>
 <button type="button" class="laa-pdf-remove-btn" data-tab="<?php echo esc_attr($tab_id); ?>"> Remove</button>
 </div>
 </div>
</div>
<?php }
}

// Template helper: Generate Contract form 
if (!function_exists('laa_render_generate_form')) {
function laa_render_generate_form($context = 'frontend') {
 $all_fields = laa_get_generate_form_fields();
 $contract_types = array_keys($all_fields);
 $prefix = ($context === 'admin') ? '' : 'f-';
 $select_class = ($context === 'admin') ? 'laa-select' : 'laa-fselect';
 $input_class = ($context === 'admin') ? 'laa-input laa-input-wide' : 'laa-fgenerate-input';
 $btn_class = ($context === 'admin') ? 'laa-btn laa-btn-success' : 'laa-fbtn laa-fbtn-success';
 $fields_json = json_encode($all_fields);
 ?>
 <div class="laa-generate-form" id="<?php echo esc_attr($prefix); ?>generate-form">

 <div class="laa-gen-field laa-gen-type-row">
 <label class="<?php echo $context === 'admin' ? 'laa-label' : 'laa-fgen-label'; ?>">Contract Type</label>
 <select id="<?php echo esc_attr($prefix); ?>contract-type" class="<?php echo esc_attr($select_class); ?> laa-gen-type-select">
 <?php foreach ($contract_types as $type): ?>
 <option value="<?php echo esc_attr($type); ?>"><?php echo esc_html($type); ?></option>
 <?php endforeach; ?>
 </select>
 </div>

 <div id="<?php echo esc_attr($prefix); ?>gen-dynamic-fields" class="laa-gen-dynamic-fields"></div>

 <button class="<?php echo esc_attr($btn_class); ?> laa-gen-submit" data-type="generate" data-prefix="<?php echo esc_attr($prefix); ?>">
 Generate Contract
 </button>
 </div>

 <script type="application/json" id="<?php echo esc_attr($prefix); ?>gen-fields-data"><?php echo $fields_json; ?></script>
 <?php
}
}

// Dashboard Home Shortcode 
// Usage: [laa_dashboard_home] — URLs are pre-configured for affermativeai.co.uk
add_shortcode('laa_dashboard_home', 'laa_dashboard_home_shortcode');
function laa_dashboard_home_shortcode($atts) {
 $atts = shortcode_atts([
 'contracts_url' => 'https://affirmativeai.co.uk/contracts/',
 'downloads_url' => 'https://affirmativeai.co.uk/user-dashboard/',
 'account_url' => 'https://affirmativeai.co.uk/account/',
 ], $atts, 'laa_dashboard_home');

 if (!is_user_logged_in()) {
 ob_start(); ?>
 <div class="laa-dash-wrap">
 <div class="laa-dash-guest">
 <div class="laa-dash-guest-icon"></div>
 <h2>Please log in to view your dashboard</h2>
 <a href="<?php echo esc_url(wp_login_url(get_permalink())); ?>" class="laa-dash-btn laa-dash-btn-primary">Log In</a>
 </div>
 </div>
 <?php return ob_get_clean();
 }

 $user = wp_get_current_user();
 $user_id = $user->ID;
 $first_name = $user->first_name ?: $user->display_name;

 // Stats 
 $saved_docs = get_posts([
 'post_type' => 'wpdmpro',
 'author' => $user_id,
 'post_status' => ['publish', 'private'],
 'posts_per_page' => -1,
 'fields' => 'ids',
 'meta_query' => [[
 'key' => '_laa_owner_user_id',
 'value' => $user_id,
 ]],
 ]);
 $doc_count = count($saved_docs);

 // Count signed contracts
 $signed_count = 0;
 foreach ($saved_docs as $did) {
 if (get_post_meta($did, '_laa_signed_by_a', true)) $signed_count++;
 }

 // Total analyses from DB
 global $wpdb;
 $analysis_count = (int) $wpdb->get_var($wpdb->prepare(
 "SELECT COUNT(*) FROM {$wpdb->prefix}laa_analyses WHERE user_id = %d",
 $user_id
 ));

 // Most used analysis type
 $top_type_row = $wpdb->get_row($wpdb->prepare(
 "SELECT analysis_type, COUNT(*) as cnt FROM {$wpdb->prefix}laa_analyses WHERE user_id = %d GROUP BY analysis_type ORDER BY cnt DESC LIMIT 1",
 $user_id
 ));
 $type_labels = [
 'analyze' => 'Full Analysis',
 'risks' => 'Risk Assessment',
 'missing' => 'Missing Clauses',
 'dates' => 'Key Dates',
 'generate' => 'Contract Draft',
 'summary' => 'Plain Summary',
 ];
 $top_type = $top_type_row ? ($type_labels[$top_type_row->analysis_type] ?? ucfirst($top_type_row->analysis_type)) : '—';
 $member_since = date('M Y', strtotime($user->user_registered));

 // Recent documents (last 5) 
 $recent_docs = get_posts([
 'post_type' => 'wpdmpro',
 'author' => $user_id,
 'post_status' => ['publish', 'private'],
 'posts_per_page' => 5,
 'orderby' => 'date',
 'order' => 'DESC',
 'meta_query' => [[
 'key' => '_laa_owner_user_id',
 'value' => $user_id,
 ]],
 ]);

 ob_start(); ?>
 <div class="laa-dash-wrap">

 <!-- Welcome header -->
 <div class="laa-dash-header">
 <div class="laa-dash-header-inner">
 <div class="laa-dash-avatar"><?php echo esc_html(strtoupper(substr($first_name, 0, 1))); ?></div>
 <div>
 <h1 class="laa-dash-welcome">Welcome back, <?php echo esc_html($first_name); ?></h1>
 <p class="laa-dash-subtitle">Your legal document hub — everything in one place</p>
 </div>
 </div>
 </div>

 <!-- Stats strip -->
 <div class="laa-dash-stats">
 <div class="laa-dash-stat">
 <span class="laa-dash-stat-number"><?php echo $doc_count; ?></span>
 <span class="laa-dash-stat-label">Documents Saved</span>
 </div>
 <div class="laa-dash-stat-divider"></div>
 <div class="laa-dash-stat">
 <span class="laa-dash-stat-number"><?php echo $signed_count; ?></span>
 <span class="laa-dash-stat-label">Signed Contracts</span>
 </div>
 <div class="laa-dash-stat-divider"></div>
 <div class="laa-dash-stat">
 <span class="laa-dash-stat-number"><?php echo $analysis_count; ?></span>
 <span class="laa-dash-stat-label">Analyses Run</span>
 </div>
 <div class="laa-dash-stat-divider"></div>
 <div class="laa-dash-stat">
 <span class="laa-dash-stat-number laa-dash-stat-sm"><?php echo esc_html($member_since); ?></span>
 <span class="laa-dash-stat-label">Member Since</span>
 </div>
 </div>

 <!-- Quick action cards -->
 <div class="laa-dash-cards">
 <a href="<?php echo esc_url($atts['contracts_url']); ?>" class="laa-dash-card">
 <div class="laa-dash-card-icon"></div>
 <div class="laa-dash-card-body">
 <strong>Contracts</strong>
 <p>Analyse or generate a legal document</p>
 </div>
 <div class="laa-dash-card-arrow">→</div>
 </a>
 <a href="<?php echo esc_url($atts['downloads_url']); ?>" class="laa-dash-card">
 <div class="laa-dash-card-icon"></div>
 <div class="laa-dash-card-body">
 <strong>Downloads &amp; Audits</strong>
 <p>Access your saved PDFs and reports</p>
 </div>
 <div class="laa-dash-card-arrow">→</div>
 </a>
 <a href="<?php echo esc_url($atts['account_url']); ?>" class="laa-dash-card">
 <div class="laa-dash-card-icon"></div>
 <div class="laa-dash-card-body">
 <strong>My Account</strong>
 <p>Manage your profile and subscription</p>
 </div>
 <div class="laa-dash-card-arrow">→</div>
 </a>
 </div>

 <!-- Recent documents -->
 <div class="laa-dash-recent">
 <div class="laa-dash-section-header">
 <h2 class="laa-dash-section-title"> Recent Documents</h2>
 <a href="<?php echo esc_url($atts['downloads_url']); ?>" class="laa-dash-see-all">See all →</a>
 </div>

 <?php if (empty($recent_docs)): ?>
 <div class="laa-dash-empty">
 <div class="laa-dash-empty-icon"></div>
 <p>No documents saved yet.</p>
 <a href="<?php echo esc_url($atts['contracts_url']); ?>" class="laa-dash-btn laa-dash-btn-primary">Run Your First Analysis</a>
 </div>
 <?php else: ?>
 <div class="laa-dash-doc-list">
 <?php foreach ($recent_docs as $doc):
 $saved_at = get_post_meta($doc->ID, '_laa_saved_at', true);
 $category = get_post_meta($doc->ID, '__wpdm_categories', true);
 $cat_label = is_array($category) ? implode(', ', $category) : ($category ?: 'Document');
 $attach_ids = get_post_meta($doc->ID, '_laa_attachment_ids', true);
 $dl_url = '';
 if (!empty($attach_ids)) {
 $dl_url = wp_get_attachment_url($attach_ids[0]);
 }
 $formatted_date = $saved_at
 ? date('j M Y, H:i', strtotime($saved_at))
 : get_the_date('j M Y', $doc->ID);

 // Check if this is a signed contract
 $signed_by_a = get_post_meta($doc->ID, '_laa_signed_by_a', true);
 $signed_by_b = get_post_meta($doc->ID, '_laa_signed_by_b', true);
 $is_signed = !empty($signed_by_a);
 ?>
 <div class="laa-dash-doc-row">
 <div class="laa-dash-doc-icon"><?php echo $is_signed ? '' : ''; ?></div>
 <div class="laa-dash-doc-info">
 <div class="laa-dash-doc-name-row">
 <span class="laa-dash-doc-name"><?php echo esc_html($doc->post_title); ?></span>
 <?php if ($is_signed): ?>
 <span class="laa-dash-signed-badge"> Signed</span>
 <?php endif; ?>
 </div>
 <span class="laa-dash-doc-meta">
 <?php echo esc_html($cat_label); ?> &nbsp;·&nbsp; <?php echo esc_html($formatted_date); ?>
 <?php if ($is_signed && $signed_by_b): ?>
 &nbsp;·&nbsp; <?php echo esc_html($signed_by_a); ?> &amp; <?php echo esc_html($signed_by_b); ?>
 <?php endif; ?>
 </span>
 </div>
 <?php if ($dl_url): ?>
 <a href="<?php echo esc_url($dl_url); ?>" class="laa-dash-doc-dl <?php echo $is_signed ? 'laa-dash-doc-dl-signed' : ''; ?>" download>
 <?php echo $is_signed ? ' Download Signed' : ' Download'; ?>
 </a>
 <?php endif; ?>
 </div>
 <?php endforeach; ?>
 </div>
 <?php endif; ?>
 </div>

 </div>
 <?php
 return ob_get_clean();
}


// Portfolio Demo Mode Fallback (runs automatically when AI Engine has no API key configured)
function laa_generate_demo_fallback($type, $text, $contract_type = '', $details = '') {
 $banner = "<div style='background:#f0f9ff;border-left:4px solid #0284c7;padding:10px 14px;margin-bottom:16px;font-size:13px;color:#0c4a6e;'><strong>Portfolio Sandbox Mode:</strong> Displaying simulated British legal analysis because no live AI Engine API key is configured in this browser sandbox.</div>";
 $snippet = esc_html(mb_substr(trim($text ?: $details), 0, 140));
 if (strlen(trim($text ?: $details)) > 140) $snippet .= '...';
 $word_count = str_word_count(wp_strip_all_tags($text ?: $details));

 switch ($type) {
 case 'risks':
 return $banner . "
 <div class='laa-section laa-risks'>
 <h3>Detailed Risk Assessment ({$word_count} words analysed)</h3>
 <p><strong>1. Uncapped Consequential &amp; Indirect Liability</strong> <span style='background:#fee2e2;color:#991b1b;padding:2px 8px;border-radius:4px;font-size:11px;font-weight:700;'>HIGH RISK</span><br>
 The submitted clause (<em>&ldquo;{$snippet}&rdquo;</em>) lacks an explicit financial liability cap under the Unfair Contract Terms Act 1977 (UCTA).<br>
 <strong>Mitigation:</strong> Cap aggregate liability at 100% of fees paid in the preceding 12 months, excluding death, personal injury, or fraud.</p>
 <p><strong>2. Asymmetric Termination Notice Period</strong> <span style='background:#fef3c7;color:#92400e;padding:2px 8px;border-radius:4px;font-size:11px;font-weight:700;'>MEDIUM RISK</span><br>
 Termination rights appear weighted towards one party without a mutual cure period for remediable material breaches.<br>
 <strong>Mitigation:</strong> Introduce a mutual 14-day written notice and cure window before termination takes effect.</p>
 <p><strong>3. Governing Law &amp; Jurisdiction</strong> <span style='background:#dcfce7;color:#166534;padding:2px 8px;border-radius:4px;font-size:11px;font-weight:700;'>LOW RISK</span><br>
 Standard commercial wording detected; confirm exclusive jurisdiction of the courts of England and Wales.</p>
 </div>";

 case 'missing':
 return $banner . "
 <div class='laa-section laa-missing'>
 <h3>Missing Standard Clauses (English Law Review)</h3>
 <ul>
 <li><strong>UK GDPR &amp; Data Protection Schedule (Critical):</strong> No processor obligations under the Data Protection Act 2018 / UK GDPR detected.<br><em>Suggested Language:</em> &ldquo;Each party shall comply with all applicable requirements of the UK GDPR and Data Protection Act 2018.&rdquo;</li>
 <li><strong>Force Majeure Clause (Important):</strong> Document omits relief for events beyond reasonable control.<br><em>Suggested Language:</em> &ldquo;Neither party shall be in breach of this Agreement nor liable for delay in performing obligations resulting from events beyond its reasonable control.&rdquo;</li>
 <li><strong>Third-Party Rights Exclusion (Optional):</strong> Add an explicit exclusion under the Contracts (Rights of Third Parties) Act 1999.</li>
 </ul>
 </div>";

 case 'dates':
 return $banner . "
 <div class='laa-section laa-dates'>
 <h3>Extracted Dates &amp; Time-Sensitive Obligations</h3>
 <table style='width:100%;border-collapse:collapse;margin-top:8px;'>
 <thead><tr style='background:#f1f5f9;text-align:left;'><th style='padding:8px;border:1px solid #cbd5e1;'>Date / Period</th><th style='padding:8px;border:1px solid #cbd5e1;'>Obligation</th><th style='padding:8px;border:1px solid #cbd5e1;'>Responsible Party</th><th style='padding:8px;border:1px solid #cbd5e1;'>Consequence if Missed</th></tr></thead>
 <tbody>
 <tr><td style='padding:8px;border:1px solid #cbd5e1;'>14 Days (Cure Window)</td><td style='padding:8px;border:1px solid #cbd5e1;'>Remedy notified material breach</td><td style='padding:8px;border:1px solid #cbd5e1;'>Defaulting Party</td><td style='padding:8px;border:1px solid #cbd5e1;'>Immediate right of termination</td></tr>
 <tr><td style='padding:8px;border:1px solid #cbd5e1;'>30 Days Net</td><td style='padding:8px;border:1px solid #cbd5e1;'>Settlement of valid VAT invoices</td><td style='padding:8px;border:1px solid #cbd5e1;'>Client / Receiving Party</td><td style='padding:8px;border:1px solid #cbd5e1;'>Statutory interest under Late Payment Act 1998</td></tr>
 <tr><td style='padding:8px;border:1px solid #cbd5e1;'>5 Years Post-Expiry</td><td style='padding:8px;border:1px solid #cbd5e1;'>Maintain strict confidentiality</td><td style='padding:8px;border:1px solid #cbd5e1;'>Receiving Party</td><td style='padding:8px;border:1px solid #cbd5e1;'>Injunctive relief &amp; damages claim</td></tr>
 </tbody>
 </table>
 </div>";

 case 'generate':
 $c_title = esc_html($contract_type ?: 'Service Level & Consultancy');
 $c_det = esc_html($details ?: 'Provision of technical consultancy and software engineering services.');
 return $banner . "
 <div class='laa-section laa-generated-contract'>
 <h2 style='text-align:center;text-transform:uppercase;'>{$c_title} Agreement</h2>
 <p><strong>THIS AGREEMENT</strong> is made on " . date('d F Y') . " between <strong>[PARTY A LEGAL NAME]</strong> (&ldquo;Client&rdquo;) and <strong>[PARTY B LEGAL NAME]</strong> (&ldquo;Supplier&rdquo;).</p>
 <p><strong>1. SCOPE OF SERVICES:</strong> The Supplier shall deliver the services described as follows: <em>{$c_det}</em>, exercising reasonable skill and care in accordance with the Supply of Goods and Services Act 1982.</p>
 <p><strong>2. CONFIDENTIALITY:</strong> Each party undertakes that it shall not at any time disclose to any person any confidential information concerning the business, affairs, or technical systems of the other party.</p>
 <p><strong>3. INTELLECTUAL PROPERTY:</strong> Upon full payment of all undisputed fees, all bespoke deliverables created specifically under this Agreement shall vest in the Client.</p>
 <p><strong>4. LIMITATION OF LIABILITY:</strong> Nothing in this Agreement limits liability for death or personal injury caused by negligence, or for fraud. Subject to this, total aggregate liability shall not exceed 100% of the fees paid under this Agreement.</p>
 <p><strong>5. GOVERNING LAW:</strong> This Agreement and any dispute arising out of it shall be governed by and construed in accordance with the law of England and Wales.</p>
 <p>[PARTY_A_SIGNATURE_BLOCK]</p>
 <p>[PARTY_B_SIGNATURE_BLOCK]</p>
 </div>";

 case 'summary':
 return $banner . "
 <div class='laa-section laa-summary'>
 <h3>Plain-English Executive Summary</h3>
 <p><strong>What This Document Is:</strong> A commercial agreement governing service delivery, payment obligations, and confidentiality between two parties ({$word_count} words reviewed).</p>
 <p><strong>Key Obligations:</strong> The supplying party must deliver agreed outputs on schedule, while the receiving party must pay invoices within standard terms and protect confidential data.</p>
 <p><strong>Overall Fairness Assessment:</strong> <span style='background:#fef3c7;color:#92400e;padding:2px 8px;border-radius:4px;font-weight:700;'>BALANCED (WITH MINOR AMENDMENTS)</span> — Core terms follow standard UK commercial practice, though liability caps and mutual notice periods should be confirmed prior to execution.</p>
 </div>";

 default:
 return $banner . "
 <div class='laa-section laa-overview'><h3>Document Overview</h3><p>Analysed <strong>{$word_count} words</strong> of legal text (<em>&ldquo;{$snippet}&rdquo;</em>). Structured as a commercial instrument governed under English law.</p></div>
 <div class='laa-section laa-risks'><h3>Risk Assessment</h3><p><strong>MEDIUM:</strong> Liability cap and termination notice reciprocity require verification prior to signing.</p></div>
 <div class='laa-section laa-missing'><h3>Missing Clauses</h3><p>UK GDPR Data Protection clause, Force Majeure, and Third-Party Rights exclusion (Contracts Act 1999).</p></div>
 <div class='laa-section laa-dates'><h3>Key Dates &amp; Deadlines</h3><p>14-day breach cure window; 30-day invoice settlement; 5-year post-termination confidentiality period.</p></div>
 <div class='laa-section laa-recommendations'><h3>Recommendations</h3><ol><li>Insert an explicit aggregate liability cap.</li><li>Ensure termination notice periods are reciprocal.</li><li>Specify exclusive jurisdiction of the courts of England and Wales.</li></ol></div>";
 }
}
