<?php if (!defined('ABSPATH')) exit; ?>
<div class="laa-frontend-wrap">
 <div class="laa-frontend-header">
 <h2> Legal Document Analyser</h2>
 <p>Upload a PDF or paste text. AI-powered contract analysis, risk detection, and more</p>
 </div>

 <div class="laa-frontend-tabs">
 <div class="laa-tab-group">
 <span class="laa-tab-group-label">Analysis</span>
 <button class="laa-ftab active" data-tab="analyse">Analyse</button>
 <button class="laa-ftab" data-tab="risks">Risks</button>
 <button class="laa-ftab" data-tab="missing">Missing Clauses</button>
 <button class="laa-ftab" data-tab="dates">Key Dates</button>
 <button class="laa-ftab" data-tab="summary">Summary</button>
 </div>
 <div class="laa-tab-divider"></div>
 <div class="laa-tab-group">
 <span class="laa-tab-group-label">Drafting</span>
 <button class="laa-ftab laa-ftab-generate" data-tab="generate">Generate Contract</button>
 </div>
 </div>

 <div class="laa-frontend-grid">
 <div class="laa-frontend-input">

 <!-- ANALYZE -->
 <div class="laa-ftab-content active" id="ftab-analyse">
 <?php laa_render_frontend_pdf_uploader('analyse'); ?>
 <div class="laa-f-divider"><span>or paste text</span></div>
 <textarea class="laa-ftextarea" id="f-analyse-text" placeholder="Paste your legal document here for full analysis..."></textarea>
 <button class="laa-fbtn laa-fbtn-primary" data-type="analyse" data-text-id="f-analyse-text"> Analyse Contract</button>
 </div>

 <!-- RISKS -->
 <div class="laa-ftab-content" id="ftab-risks">
 <?php laa_render_frontend_pdf_uploader('risks'); ?>
 <div class="laa-f-divider"><span>or paste text</span></div>
 <textarea class="laa-ftextarea" id="f-risks-text" placeholder="Paste contract to assess risks..."></textarea>
 <button class="laa-fbtn laa-fbtn-danger" data-type="risks" data-text-id="f-risks-text"> Assess Risks</button>
 </div>

 <!-- MISSING CLAUSES -->
 <div class="laa-ftab-content" id="ftab-missing">
 <?php laa_render_frontend_pdf_uploader('missing'); ?>
 <div class="laa-f-divider"><span>or paste text</span></div>
 <textarea class="laa-ftextarea" id="f-missing-text" placeholder="Paste contract to detect missing clauses..."></textarea>
 <button class="laa-fbtn laa-fbtn-warning" data-type="missing" data-text-id="f-missing-text"> Detect Missing Clauses</button>
 </div>

 <!-- DATES -->
 <div class="laa-ftab-content" id="ftab-dates">
 <?php laa_render_frontend_pdf_uploader('dates'); ?>
 <div class="laa-f-divider"><span>or paste text</span></div>
 <textarea class="laa-ftextarea" id="f-dates-text" placeholder="Paste document to extract key dates..."></textarea>
 <button class="laa-fbtn laa-fbtn-info" data-type="dates" data-text-id="f-dates-text"> Extract Dates</button>
 </div>

 <!-- GENERATE -->
 <div class="laa-ftab-content" id="ftab-generate">
 <?php laa_render_generate_form('frontend'); ?>
 </div>

 <!-- SUMMARY -->
 <div class="laa-ftab-content" id="ftab-summary">
 <?php laa_render_frontend_pdf_uploader('summary'); ?>
 <div class="laa-f-divider"><span>or paste text</span></div>
 <textarea class="laa-ftextarea" id="f-summary-text" placeholder="Paste your legal document for a plain-English summary..."></textarea>
 <button class="laa-fbtn laa-fbtn-purple" data-type="summary" data-text-id="f-summary-text"> Summarise Document</button>
 </div>

 </div>

 <!-- Results panel -->
 <div class="laa-frontend-output">
 <div id="f-loading" class="laa-f-loading" style="display:none;">
 <div class="laa-f-spinner"></div>
 <p id="f-loading-text">Analysing with AI... Please wait.</p>
 </div>

 <div id="f-placeholder" class="laa-f-placeholder">
 <span></span>
 <p>Upload a PDF or paste text, then click analyse</p>
 <small style="color:#9ca3af;font-size:12px;"> PDF upload supported on all analysis tabs</small>
 </div>

 <div id="f-results" style="display:none;"></div>

 <?php if (is_user_logged_in()): ?>
 <div id="f-save-panel" class="laa-save-panel" style="display:none;">
 <div class="laa-save-panel-header">
 <div>
 <strong>Save to Your Dashboard</strong>
 <span id="f-save-count" class="laa-save-count"></span>
 <p>Select which analyses to bundle into one PDF and save to your document library.</p>
 </div>
 </div>
 <div id="f-save-checklist" class="laa-save-checklist"></div>
 <div class="laa-save-fields">
 <div class="laa-save-field">
 <label for="f-save-name">Document Name</label>
 <input type="text" id="f-save-name" class="laa-save-input" placeholder="e.g. Supplier Agreement — Acme Ltd" maxlength="120" />
 </div>
 <div class="laa-save-field">
 <label for="f-save-category">Category</label>
 <select id="f-save-category" class="laa-save-select">
 <?php foreach (laa_get_categories() as $cat): ?>
 <option value="<?php echo esc_attr($cat); ?>"><?php echo esc_html($cat); ?></option>
 <?php endforeach; ?>
 </select>
 </div>
 </div>
 <button id="f-save-btn" class="laa-fbtn laa-fbtn-save">
 <span class="laa-save-btn-text">Save to Dashboard</span>
 </button>
 <div id="f-save-status" class="laa-save-status" style="display:none;"></div>
 </div>
 <?php else: ?>
 <div id="f-save-panel" class="laa-save-panel laa-save-panel-guest" style="display:none;">
 <p><strong>Log in to save analyses</strong> as a PDF to your personal dashboard.</p>
 <a href="<?php echo esc_url(wp_login_url(get_permalink())); ?>" class="laa-fbtn laa-fbtn-save">Log In to Save</a>
 </div>
 <?php endif; ?>

 <!-- Sign Contract button — shown only after a contract is generated -->
 <div id="f-sign-section" style="display:none;" class="laa-sign-section">
 <div class="laa-sign-divider-line"></div>
 <div class="laa-sign-intro">
 <strong> Ready to sign this contract?</strong>
 <p>Both parties can sign right now. The signed copy will be saved automatically to your document library.</p>
 </div>
 <button class="laa-fbtn laa-fbtn-sign" id="f-open-sign-modal" type="button"> Sign This Contract</button>
 </div>

 </div>
 </div>
</div>

<!-- SIGNATURE MODAL -->
<div id="laa-sign-modal" class="laa-sign-overlay" style="display:none;" aria-modal="true" role="dialog">
 <div class="laa-sign-box">

 <div class="laa-sign-header">
 <div>
 <h3> Sign Contract</h3>
 <p>Both parties must sign. The signed contract will be saved to your document library automatically.</p>
 </div>
 <button class="laa-sign-close" id="laa-sign-close" type="button" aria-label="Close"></button>
 </div>

 <div class="laa-sign-body">

 <!-- Party details -->
 <div class="laa-sign-parties">
 <div class="laa-sign-party">
 <div class="laa-sign-party-label">Party A</div>
 <input type="text" id="laa-sign-name-a" class="laa-sign-input" placeholder="Full legal name *" />
 <input type="email" id="laa-sign-email-a" class="laa-sign-input" placeholder="Email address (optional)" />
 </div>
 <div class="laa-sign-party">
 <div class="laa-sign-party-label">Party B</div>
 <input type="text" id="laa-sign-name-b" class="laa-sign-input" placeholder="Full legal name *" />
 <input type="email" id="laa-sign-email-b" class="laa-sign-input" placeholder="Email address (optional)" />
 </div>
 </div>

 <!-- Mode toggle -->
 <div class="laa-sign-toggle">
 <button class="laa-sign-tab active" data-mode="draw" type="button">Draw Signature</button>
 <button class="laa-sign-tab" data-mode="type" type="button">Type Signature</button>
 </div>

 <!-- Draw mode -->
 <div id="laa-sign-draw-mode">
 <div class="laa-sign-pads">
 <div class="laa-sign-pad-wrap">
 <div class="laa-sign-pad-label">Party A — Draw</div>
 <div class="laa-sign-canvas-wrap">
 <canvas id="laa-canvas-a" class="laa-sign-canvas" width="320" height="110"></canvas>
 <div class="laa-sign-baseline"></div>
 <div class="laa-sign-hint" id="laa-hint-a">Sign here</div>
 </div>
 <button class="laa-sign-clear" data-canvas="laa-canvas-a" data-hint="laa-hint-a" type="button">Clear</button>
 </div>
 <div class="laa-sign-pad-wrap">
 <div class="laa-sign-pad-label">Party B — Draw</div>
 <div class="laa-sign-canvas-wrap">
 <canvas id="laa-canvas-b" class="laa-sign-canvas" width="320" height="110"></canvas>
 <div class="laa-sign-baseline"></div>
 <div class="laa-sign-hint" id="laa-hint-b">Sign here</div>
 </div>
 <button class="laa-sign-clear" data-canvas="laa-canvas-b" data-hint="laa-hint-b" type="button">Clear</button>
 </div>
 </div>
 </div>

 <!-- Type mode -->
 <div id="laa-sign-type-mode" style="display:none;">
 <div class="laa-sign-pads">
 <div class="laa-sign-pad-wrap">
 <div class="laa-sign-pad-label">Party A — Type Name</div>
 <div class="laa-sign-type-wrap">
 <input type="text" id="laa-type-a" class="laa-sign-type-input" placeholder="Type full name to sign..." maxlength="60" />
 <div class="laa-sign-type-preview" id="laa-type-preview-a"></div>
 <div class="laa-sign-baseline"></div>
 </div>
 </div>
 <div class="laa-sign-pad-wrap">
 <div class="laa-sign-pad-label">Party B — Type Name</div>
 <div class="laa-sign-type-wrap">
 <input type="text" id="laa-type-b" class="laa-sign-type-input" placeholder="Type full name to sign..." maxlength="60" />
 <div class="laa-sign-type-preview" id="laa-type-preview-b"></div>
 <div class="laa-sign-baseline"></div>
 </div>
 </div>
 </div>
 </div>

 <div class="laa-sign-notice">
 By clicking "Sign &amp; Save Contract" both parties confirm they have read, understood, and agree to the terms of this contract. This electronic signature is legally binding under the Electronic Communications Act 2000 and eIDAS Regulation.
 </div>

 <div id="laa-sign-error" class="laa-sign-error" style="display:none;"></div>

 <div class="laa-sign-actions">
 <button class="laa-fbtn laa-fbtn-primary" id="laa-sign-submit" type="button"> Sign &amp; Save Contract</button>
 <button class="laa-sign-cancel-btn" id="laa-sign-cancel" type="button">Cancel</button>
 </div>

 <div id="laa-sign-loading" style="display:none;" class="laa-sign-loading">
 <div class="laa-f-spinner"></div>
 <p>Saving signed contract to your document library...</p>
 </div>

 <!-- Success state -->
 <div id="laa-sign-success" style="display:none;" class="laa-sign-success">
 <div class="laa-sign-success-icon"></div>
 <h4>Contract Signed &amp; Saved!</h4>
 <p id="laa-sign-success-msg"></p>
 <a id="laa-sign-success-link" href="#" target="_blank" class="laa-fbtn laa-fbtn-primary" style="display:none;">View in Dashboard →</a>
 <button class="laa-sign-cancel-btn" id="laa-sign-done" type="button" style="margin-top:8px;">Close</button>
 </div>

 </div>
 </div>
</div>
