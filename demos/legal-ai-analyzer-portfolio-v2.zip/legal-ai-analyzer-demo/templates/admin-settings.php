<?php if (!defined('ABSPATH')) exit; ?>
<div class="wrap laa-wrap">
 <div class="laa-header laa-header-simple">
 <h1 class="laa-title">Legal AI Analyser — Settings</h1>
 </div>

 <?php if (isset($_GET['settings-updated'])): ?>
 <div class="laa-notice laa-notice-success">Settings saved successfully.</div>
 <?php endif; ?>

 <?php
 $ai_engine_active = (function_exists('mwai_get_core') || class_exists('Meow_MWAI_Core') || isset($GLOBALS['mwai']));
 ?>

 <?php if (!$ai_engine_active): ?>
 <div class="laa-notice laa-notice-warning">
 <strong>AI Engine Not Detected:</strong> This plugin requires the <a href="https://wordpress.org/plugins/ai-engine/" target="_blank">AI Engine plugin</a> to be installed and activated. <a href="<?php echo admin_url('plugin-install.php?s=ai+engine+meow&tab=search&type=term'); ?>">Install AI Engine</a>
 </div>
 <?php else: ?>
 <div class="laa-notice laa-notice-success">
 <strong>AI Engine detected and active.</strong> Legal AI Analyser will use your AI Engine configuration automatically.
 </div>
 <?php endif; ?>

 <div class="laa-settings-grid">
 <div class="laa-panel">
 <h3 class="laa-panel-title">AI Engine Configuration</h3>

 <div class="laa-notice laa-notice-info" style="margin-bottom:24px;">
 <strong>No API key required here.</strong> Legal AI Analyser uses AI Engine to handle all AI calls. Configure your AI provider directly in <a href="<?php echo admin_url('admin.php?page=mwai_settings'); ?>">AI Engine Settings</a>.
 </div>

 <form method="post" action="options.php">
 <?php settings_fields('laa_settings_group'); ?>

 <div class="laa-form-group">
 <label class="laa-label" for="laa_ai_engine_model">
 Model Override
 <span style="font-weight:400;font-size:11px;color:#9ca3af;">(optional)</span>
 </label>
 <input type="text" id="laa_ai_engine_model" name="laa_ai_engine_model"
 class="laa-input laa-input-wide"
 value="<?php echo esc_attr(get_option('laa_ai_engine_model', '')); ?>"
 placeholder="Leave blank to use AI Engine's default model" />
 <p class="laa-field-hint">
 Leave blank to use the model configured in AI Engine. To override, enter a model ID such as: <code>gpt-4o</code>, <code>gpt-4o-mini</code>, <code>claude-opus-4-5</code>, <code>gemini-1.5-pro</code>
 </p>
 </div>

 <div class="laa-form-group">
 <label class="laa-label" for="laa_max_tokens">Maximum Response Tokens</label>
 <input type="number" id="laa_max_tokens" name="laa_max_tokens"
 class="laa-input"
 value="<?php echo esc_attr(get_option('laa_max_tokens', 4000)); ?>"
 min="1000" max="16000" />
 <p class="laa-field-hint">Higher values produce more detailed responses. Default: 4000.</p>
 </div>

 <button type="submit" class="laa-btn laa-btn-primary">Save Settings</button>
 </form>

 <?php if ($ai_engine_active): ?>
 <div style="margin-top:24px;padding-top:20px;border-top:1px solid var(--laa-border);">
 <h4 style="margin:0 0 12px;font-size:14px;color:var(--laa-primary);">Quick Links</h4>
 <a href="<?php echo admin_url('admin.php?page=mwai_settings'); ?>" class="laa-btn laa-btn-primary" style="margin-right:8px;margin-bottom:8px;display:inline-flex;">AI Engine Settings</a>
 <a href="<?php echo admin_url('admin.php?page=mwai_stats'); ?>" class="laa-btn" style="background:var(--laa-secondary);color:var(--laa-text);border:1px solid var(--laa-border);margin-bottom:8px;display:inline-flex;">AI Engine Usage Stats</a>
 </div>
 <?php endif; ?>
 </div>

 <div class="laa-panel">
 <h3 class="laa-panel-title">How It Works</h3>
 <div class="laa-docs">
 <div class="laa-doc-item">
 <span class="laa-doc-num">1</span>
 <div>
 <strong>Install AI Engine</strong>
 <p>Install the free <a href="https://wordpress.org/plugins/ai-engine/" target="_blank">AI Engine plugin</a> from WordPress.org and activate it.</p>
 </div>
 </div>
 <div class="laa-doc-item">
 <span class="laa-doc-num">2</span>
 <div>
 <strong>Configure Your AI Provider</strong>
 <p>In <a href="<?php echo admin_url('admin.php?page=mwai_settings'); ?>">AI Engine Settings</a>, add your API key for OpenAI, Claude, Gemini, or any supported provider.</p>
 </div>
 </div>
 <div class="laa-doc-item">
 <span class="laa-doc-num">3</span>
 <div>
 <strong>Start Analysing</strong>
 <p>Legal AI Analyser will automatically use AI Engine for all queries — no further setup required.</p>
 </div>
 </div>
 <div class="laa-doc-item">
 <span class="laa-doc-num">4</span>
 <div>
 <strong>Frontend Shortcode</strong>
 <code class="laa-code">[legal_ai_analyzer]</code>
 <p>Embed the full analyser on any page or post using this shortcode.</p>
 </div>
 </div>
 </div>


 </div>
 </div>
</div>
