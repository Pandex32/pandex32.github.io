<?php if (!defined('ABSPATH')) exit; ?>
<div class="wrap laa-wrap">
 <div class="laa-header laa-header-simple">
 <h1 class="laa-title"> Analysis History</h1>
 <button class="laa-btn laa-btn-danger laa-btn-sm" id="clear-all-history"> Clear All</button>
 </div>

 <?php
 global $wpdb;
 $items = $wpdb->get_results("SELECT * FROM {$wpdb->prefix}laa_analyses ORDER BY created_at DESC LIMIT 100");
 ?>

 <?php if (empty($items)): ?>
 <div class="laa-panel laa-empty-state">
 <div class="laa-placeholder-icon"></div>
 <h4>No Analysis History Yet</h4>
 <p>Your AI analyses will appear here after you analyse documents.</p>
 <a href="<?php echo admin_url('admin.php?page=legal-ai-analyser'); ?>" class="laa-btn laa-btn-primary">Start Analyzing →</a>
 </div>
 <?php else: ?>

 <div class="laa-panel">
 <table class="laa-table">
 <thead>
 <tr>
 <th>Date</th>
 <th>Type</th>
 <th>Document Preview</th>
 <th>Actions</th>
 </tr>
 </thead>
 <tbody>
 <?php foreach ($items as $item): ?>
 <tr id="history-row-<?php echo $item->id; ?>">
 <td class="laa-td-date"><?php echo esc_html(date('M j, Y g:i A', strtotime($item->created_at))); ?></td>
 <td>
 <span class="laa-badge laa-badge-<?php echo esc_attr($item->analysis_type); ?>">
 <?php echo esc_html(ucfirst($item->analysis_type)); ?>
 </span>
 </td>
 <td class="laa-td-preview"><?php echo esc_html(substr($item->document_name, 0, 80)) . '...'; ?></td>
 <td>
 <button class="laa-btn-sm laa-view-result" data-id="<?php echo $item->id; ?>" data-result="<?php echo esc_attr($item->result); ?>"> View</button>
 <button class="laa-btn-sm laa-btn-danger-sm laa-delete-history" data-id="<?php echo $item->id; ?>"></button>
 </td>
 </tr>
 <?php endforeach; ?>
 </tbody>
 </table>
 </div>

 <!-- Result Modal -->
 <div id="laa-modal" class="laa-modal" style="display:none;">
 <div class="laa-modal-overlay"></div>
 <div class="laa-modal-content">
 <div class="laa-modal-header">
 <h3>Analysis Result</h3>
 <button class="laa-modal-close"></button>
 </div>
 <div class="laa-modal-body" id="laa-modal-body"></div>
 </div>
 </div>

 <?php endif; ?>
</div>

<script>
jQuery(document).ready(function($) {
 $('.laa-view-result').on('click', function() {
 var result = $(this).data('result');
 $('#laa-modal-body').html(result);
 $('#laa-modal').show();
 });

 $('.laa-modal-close, .laa-modal-overlay').on('click', function() {
 $('#laa-modal').hide();
 });

 $('.laa-delete-history').on('click', function() {
 if (!confirm('Delete this analysis?')) return;
 var id = $(this).data('id');
 $.post(laaData.ajaxUrl, { action: 'laa_delete_history', nonce: laaData.nonce, id: id }, function(res) {
 if (res.success) $('#history-row-' + id).fadeOut();
 });
 });
});
</script>
