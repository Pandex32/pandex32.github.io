<?php if (!defined('ABSPATH')) exit; ?>
<div class="wrap laa-wrap">
 <div class="laa-header">
 <div class="laa-header-inner">
 <div class="laa-logo">
 <svg width="36" height="36" viewBox="0 0 36 36" fill="none" xmlns="http://www.w3.org/2000/svg">
 <rect width="36" height="36" rx="8" fill="#1a1a2e"/>
 <path d="M10 8h16v2H10zM10 13h12v2H10zM10 18h16v2H10zM10 23h8v2H10z" fill="#c9a84c"/>
 <circle cx="27" cy="24" r="5" fill="#c9a84c" opacity="0.9"/>
 <path d="M25 24l1.5 1.5L29 22" stroke="#1a1a2e" stroke-width="1.5" stroke-linecap="round"/>
 </svg>
 </div>
 <div>
 <h1 class="laa-title">Legal AI Analyzer</h1>
 <p class="laa-subtitle">Powered by AI Engine — Analyse, Generate & Review Legal Documents</p>
 </div>
 </div>
 <div class="laa-header-stats">
 <?php
 global $wpdb;
 $total = $wpdb->get_var("SELECT COUNT(*) FROM {$wpdb->prefix}laa_analyses");
 $today = $wpdb->get_var("SELECT COUNT(*) FROM {$wpdb->prefix}laa_analyses WHERE DATE(created_at) = CURDATE()");
 $ai_engine_active = (function_exists('mwai_get_core') || class_exists('Meow_MWAI_Core') || isset($GLOBALS['mwai']));
 ?>
 <div class="laa-stat"><span class="laa-stat-num"><?php echo (int)$total; ?></span><span class="laa-stat-label">Total Analyses</span></div>
 <div class="laa-stat"><span class="laa-stat-num"><?php echo (int)$today; ?></span><span class="laa-stat-label">Today</span></div>
 <div class="laa-stat laa-stat-status">
 <span class="laa-status-dot <?php echo $ai_engine_active ? 'active' : 'inactive'; ?>"></span>
 <span class="laa-stat-label">AI Engine <?php echo $ai_engine_active ? 'Active' : 'Not Found'; ?></span>
 </div>
 </div>
 </div>

 <?php if (!$ai_engine_active): ?>
 <div class="laa-notice laa-notice-warning">
 <strong> AI Engine Required:</strong> Please <a href="<?php echo admin_url('plugin-install.php?s=ai+engine+meow&tab=search&type=term'); ?>">install and activate AI Engine</a> to use Legal AI Analyzer.
 </div>
 <?php endif; ?>

 <div class="laa-tabs">
 <div class="laa-tab-group">
 <span class="laa-tab-group-label">Analysis</span>
 <button class="laa-tab active" data-tab="analyze">Analyse Contract</button>
 <button class="laa-tab" data-tab="risks">Risk Assessment</button>
 <button class="laa-tab" data-tab="missing">Missing Clauses</button>
 <button class="laa-tab" data-tab="dates">Key Dates</button>
 <button class="laa-tab" data-tab="summary">Plain Summary</button>
 </div>
 <div class="laa-tab-divider"></div>
 <div class="laa-tab-group">
 <span class="laa-tab-group-label">Drafting</span>
 <button class="laa-tab laa-tab-generate" data-tab="generate">Generate Contract</button>
 </div>
 </div>

 <div class="laa-main-grid">
 <div class="laa-panel laa-input-panel">

 <!-- ANALYZE — PDF + text -->
 <div class="laa-tab-content active" id="tab-analyze">
 <h3 class="laa-panel-title">Full Contract Analysis</h3>
 <p class="laa-panel-desc">Upload a PDF or paste your contract text for comprehensive AI analysis.</p>
 <?php laa_render_pdf_uploader('analyze'); ?>
 <div class="laa-divider"><span>or type / paste text</span></div>
 <textarea id="analyze-text" class="laa-textarea" placeholder="Paste your legal document here...&#10;&#10;The AI will analyse:&#10;• Document overview and parties&#10;• Risk assessment (High/Medium/Low)&#10;• Missing standard clauses&#10;• Key dates and deadlines&#10;• Actionable recommendations" rows="10"></textarea>
 <button class="laa-btn laa-btn-primary" data-type="analyze" data-text-id="analyze-text"> Analyse Document</button>
 </div>

 <!-- RISKS — PDF + text -->
 <div class="laa-tab-content" id="tab-risks">
 <h3 class="laa-panel-title">Risk Assessment</h3>
 <p class="laa-panel-desc">Upload a PDF or paste your contract to identify and rate legal risks.</p>
 <?php laa_render_pdf_uploader('risks'); ?>
 <div class="laa-divider"><span>or type / paste text</span></div>
 <textarea id="risks-text" class="laa-textarea" placeholder="Paste your contract to assess legal risks..." rows="10"></textarea>
 <button class="laa-btn laa-btn-danger" data-type="risks" data-text-id="risks-text"> Assess Risks</button>
 </div>

 <!-- MISSING CLAUSES — PDF + text -->
 <div class="laa-tab-content" id="tab-missing">
 <h3 class="laa-panel-title">Missing Clause Detection</h3>
 <p class="laa-panel-desc">Upload a PDF or paste your contract to detect absent standard clauses.</p>
 <?php laa_render_pdf_uploader('missing'); ?>
 <div class="laa-divider"><span>or type / paste text</span></div>
 <textarea id="missing-text" class="laa-textarea" placeholder="Paste your contract to check for missing clauses..." rows="10"></textarea>
 <button class="laa-btn laa-btn-warning" data-type="missing" data-text-id="missing-text"> Detect Missing Clauses</button>
 </div>

 <!-- DATES — PDF + text -->
 <div class="laa-tab-content" id="tab-dates">
 <h3 class="laa-panel-title">Key Date Extraction</h3>
 <p class="laa-panel-desc">Upload a PDF or paste your document to extract all key dates and deadlines.</p>
 <?php laa_render_pdf_uploader('dates'); ?>
 <div class="laa-divider"><span>or type / paste text</span></div>
 <textarea id="dates-text" class="laa-textarea" placeholder="Paste your document to extract key dates..." rows="10"></textarea>
 <button class="laa-btn laa-btn-info" data-type="dates" data-text-id="dates-text"> Extract Key Dates</button>
 </div>

 <!-- GENERATE — structured form -->
 <div class="laa-tab-content" id="tab-generate">
 <h3 class="laa-panel-title">Contract Generator</h3>
 <p class="laa-panel-desc">Fill in the form below and the AI will draft a complete, legally sound contract.</p>
 <?php laa_render_generate_form('admin'); ?>
 </div>

 <!-- SUMMARY — PDF + text -->
 <div class="laa-tab-content" id="tab-summary">
 <h3 class="laa-panel-title">Plain Language Summary</h3>
 <p class="laa-panel-desc">Upload a PDF or paste your document for a plain-English summary.</p>
 <?php laa_render_pdf_uploader('summary'); ?>
 <div class="laa-divider"><span>or type / paste text</span></div>
 <textarea id="summary-text" class="laa-textarea" placeholder="Paste your legal document for a plain-language summary..." rows="10"></textarea>
 <button class="laa-btn laa-btn-purple" data-type="summary" data-text-id="summary-text"> Generate Summary</button>
 </div>

 </div>

 <!-- Results Panel -->
 <div class="laa-panel laa-results-panel">
 <div class="laa-results-header">
 <h3 class="laa-panel-title">Analysis Results</h3>
 <div class="laa-results-actions" id="results-actions" style="display:none;">
 <button class="laa-btn-sm" id="copy-results"> Copy</button>
 <button class="laa-btn-sm" id="print-results"> Print</button>
 </div>
 </div>

 <div id="laa-loading" class="laa-loading" style="display:none;">
 <div class="laa-spinner"></div>
 <div class="laa-loading-text">
 <p class="laa-loading-main" id="loading-main-text">Analysing via AI Engine...</p>
 <p class="laa-loading-sub" id="loading-sub-text">This may take 15–30 seconds for complex documents</p>
 </div>
 </div>

 <div id="laa-placeholder" class="laa-placeholder">
 <div class="laa-placeholder-icon"></div>
 <h4>Ready to Analyse</h4>
 <p>Upload a PDF or paste your document, then click an analysis button.</p>
 <div class="laa-features-list">
 <div class="laa-feature"> PDF upload supported</div>
 <div class="laa-feature"> Full contract analysis</div>
 <div class="laa-feature"> Risk detection & rating</div>
 <div class="laa-feature"> Missing clause detection</div>
 <div class="laa-feature"> Key date extraction</div>
 <div class="laa-feature"> Contract generation</div>
 </div>
 <?php if ($ai_engine_active): ?>
 <p style="margin-top:16px;font-size:12px;color:#9ca3af;">
 Using AI Engine —
 <a href="<?php echo admin_url('admin.php?page=mwai_settings'); ?>">Configure model in AI Engine Settings</a>
 </p>
 <?php endif; ?>
 </div>

 <div id="laa-results" class="laa-results-content" style="display:none;"></div>
 </div>
 </div>
</div>

