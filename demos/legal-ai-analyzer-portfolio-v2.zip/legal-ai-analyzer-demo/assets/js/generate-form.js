/**
 * Legal AI Analyser — Generate Contract Form
 * Handles dynamic field rendering when contract type changes,
 * and serialises all fields into a structured prompt for the AI.
 * Works for both admin (prefix='') and frontend (prefix='f-') contexts.
 */
(function ($) {

    function initGenerateForm(prefix) {
        var typeSelectId    = '#' + prefix + 'contract-type';
        var dynamicFieldsId = '#' + prefix + 'gen-dynamic-fields';
        var fieldsDataId    = '#' + prefix + 'gen-fields-data';

        var allFields = JSON.parse($(fieldsDataId).text() || '{}');

        function renderFields(contractType) {
            var fields = allFields[contractType];
            if (!fields) return;

            var $container = $(dynamicFieldsId);
            $container.html('');

            $.each(fields, function (i, field) {
                var id       = prefix + 'gen-' + field.id;
                var required = field.required ? '<span class="laa-gen-required">*</span>' : '';
                var input    = '';

                if (field.type === 'text' || field.type === 'date') {
                    input = '<input type="' + field.type + '" id="' + id + '" ' +
                            'class="laa-gen-input" ' +
                            'placeholder="' + (field.placeholder || '') + '" ' +
                            (field.required ? 'required' : '') + '>';

                } else if (field.type === 'textarea') {
                    input = '<textarea id="' + id + '" class="laa-gen-textarea" rows="3" ' +
                            'placeholder="' + (field.placeholder || '') + '" ' +
                            (field.required ? 'required' : '') + '></textarea>';

                } else if (field.type === 'select') {
                    input = '<select id="' + id + '" class="laa-gen-select">';
                    $.each(field.options, function (j, opt) {
                        input += '<option value="' + opt + '">' + opt + '</option>';
                    });
                    input += '</select>';
                }

                $container.append(
                    '<div class="laa-gen-field">' +
                    '<label class="laa-gen-label" for="' + id + '">' + field.label + required + '</label>' +
                    input +
                    '</div>'
                );
            });
        }

        // Initial render
        var initialType = $(typeSelectId).val();
        if (initialType) renderFields(initialType);

        // Re-render on type change
        $(document).on('change', typeSelectId, function () {
            renderFields($(this).val());
        });
    }

    // Collect all filled fields and build a structured details string for the AI
    window.laaCollectGenerateForm = function (prefix) {
        var contractType = $('#' + prefix + 'contract-type').val();
        var lines = ['Contract Type: ' + contractType, ''];

        $('#' + prefix + 'gen-dynamic-fields .laa-gen-field').each(function () {
            var $label = $(this).find('.laa-gen-label');
            var $input = $(this).find('input, textarea, select');
            if (!$label.length || !$input.length) return;

            var label = $label.text().replace('*', '').trim();
            var value = $input.val() ? $input.val().trim() : '';
            if (value) {
                lines.push(label + ': ' + value);
            }
        });

        return { contractType: contractType, details: lines.join('\n') };
    };

    $(document).ready(function () {
        // Init for any forms present on the page
        if ($('#generate-form').length)   initGenerateForm('');
        if ($('#f-generate-form').length) initGenerateForm('f-');
    });

}(jQuery));
