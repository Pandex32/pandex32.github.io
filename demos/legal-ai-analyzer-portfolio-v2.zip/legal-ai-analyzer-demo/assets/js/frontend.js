jQuery(document).ready(function ($) {

 // Session state 
 var fPdfTextStore = {}; // { tabId: 'extracted text' }
 var fPdfFilenames = {}; // { tabId: 'filename.pdf' }

 // All analyses run this session: { type: { html, label, timestamp } }
 var sessionResults = {};

 var typeLabels = {
 'analyze': 'Full Contract Analysis',
 'risks': 'Risk Assessment',
 'missing': 'Missing Clause Detection',
 'dates': 'Key Date Extraction',
 'generate': 'Contract Draft',
 'summary': 'Plain Language Summary'
 };

 var categoryMap = {
 'analyze': 'Contract Analysis',
 'risks': 'Risk Assessment',
 'missing': 'Missing Clauses',
 'dates': 'Key Dates',
 'generate': 'Contract Draft',
 'summary': 'Plain Summary'
 };

 // Tab switching 
 $('.laa-ftab').on('click', function () {
 $('.laa-ftab').removeClass('active');
 $(this).addClass('active');
 $('.laa-ftab-content').removeClass('active');
 $('#ftab-' + $(this).data('tab')).addClass('active');
 });

 // PDF: Browse button 
 $(document).on('click', '.laa-f-pdf-browse', function () {
 $('#' + $(this).data('input')).trigger('click');
 });

 // PDF: File input change 
 $(document).on('change', '.laa-f-pdf-input', function () {
 var file = this.files[0];
 var tabId = $(this).attr('id').replace('f-pdf-input-', '');
 if (file) fHandlePdf(file, tabId);
 });

 // PDF: Drag & drop 
 $(document).on('dragover dragenter', '.laa-f-pdf-drop', function (e) {
 e.preventDefault();
 $(this).addClass('laa-f-drag-over');
 });
 $(document).on('dragleave', '.laa-f-pdf-drop', function (e) {
 e.preventDefault();
 $(this).removeClass('laa-f-drag-over');
 });
 $(document).on('drop', '.laa-f-pdf-drop', function (e) {
 e.preventDefault();
 $(this).removeClass('laa-f-drag-over');
 var tabId = $(this).attr('id').replace('f-pdf-drop-', '');
 var file = e.originalEvent.dataTransfer.files[0];
 if (file) {
 if (file.type !== 'application/pdf' && !file.name.match(/\.pdf$/i)) {
 alert('Only PDF files are accepted.');
 return;
 }
 fHandlePdf(file, tabId);
 }
 });

 // PDF: Remove 
 $(document).on('click', '.laa-f-pdf-remove', function () {
 var tabId = $(this).data('tab');
 delete fPdfTextStore[tabId];
 delete fPdfFilenames[tabId];
 $('#f-pdf-input-' + tabId).val('');
 $('#f-pdf-status-' + tabId).hide();
 $('#f-pdf-loading-' + tabId).hide();
 $('#f-pdf-drop-' + tabId).show();
 $('#f-' + tabId + '-text').val('').attr('placeholder', 'Paste text here...');
 });

 // PDF: Upload and extract 
 function fHandlePdf(file, tabId) {
 if (file.size > 10 * 1024 * 1024) {
 alert('PDF must be under 10MB.');
 return;
 }
 $('#f-pdf-drop-' + tabId).hide();
 $('#f-pdf-status-' + tabId).hide();
 $('#f-pdf-loading-' + tabId).show();

 var formData = new FormData();
 formData.append('action', 'laa_extract_pdf');
 formData.append('nonce', laaData.nonce);
 formData.append('pdf_file', file);

 $.ajax({
 url: laaData.ajaxUrl,
 method: 'POST',
 data: formData,
 processData: false,
 contentType: false,
 timeout: 60000,
 success: function (res) {
 $('#f-pdf-loading-' + tabId).hide();
 if (res.success) {
 fPdfTextStore[tabId] = res.data.text;
 fPdfFilenames[tabId] = res.data.filename;
 $('#f-pdf-filename-' + tabId).text(res.data.filename);
 $('#f-pdf-summary-' + tabId).text(res.data.summary);
 $('#f-pdf-status-' + tabId).show();
 $('#f-' + tabId + '-text').val('').attr('placeholder', ' PDF loaded — click Analyse, or paste text to override');
 // Pre-fill save name from filename
 var nameNoExt = res.data.filename.replace(/\.pdf$/i, '').replace(/[-_]/g, ' ');
 if ($('#f-save-name').val() === '') {
 $('#f-save-name').val(nameNoExt);
 }
 } else {
 $('#f-pdf-drop-' + tabId).show();
 alert('PDF Error: ' + (res.data.message || 'Extraction failed.'));
 }
 },
 error: function () {
 $('#f-pdf-loading-' + tabId).hide();
 $('#f-pdf-drop-' + tabId).show();
 alert('Upload failed. Please try again.');
 }
 });
 }

 // Analysis buttons 
 $(document).on('click', '.laa-fbtn[data-type]', function () {
 var type = $(this).data('type');
 var textareaId = $(this).data('text-id') || ('f-' + type + '-text');
 var documentText = '';
 var contractType = '';
 var contractDetails = '';

 if (type === 'generate') {
 var formData = window.laaCollectGenerateForm('f-');
 contractType = formData.contractType;
 contractDetails = formData.details;
 if (!contractDetails.trim()) {
 alert('Please fill in at least the party names and key details.');
 return;
 }
 } else {
 documentText = (fPdfTextStore[type] && fPdfTextStore[type].trim())
 ? fPdfTextStore[type]
 : $('#' + textareaId).val();
 if (!documentText.trim()) {
 alert('Please upload a PDF or paste document text.');
 return;
 }
 }

 var source = fPdfTextStore[type] ? 'PDF' : 'text';
 $('#f-placeholder').hide();
 $('#f-results').hide().html('');
 $('#f-save-panel').hide();
 $('#f-loading-text').text(source === 'PDF' ? 'Analysing PDF via AI Engine...' : 'Analysing with AI...');
 $('#f-loading').show();

 $.ajax({
 url: laaData.ajaxUrl,
 method: 'POST',
 timeout: 180000,
 data: {
 action: 'laa_analyze_document',
 nonce: laaData.nonce,
 analysis_type: type,
 document_text: documentText,
 contract_type: contractType,
 contract_details: contractDetails
 },
 success: function (res) {
 $('#f-loading').hide();
 if (res.success) {
 // Store this result in the session store
 var now = new Date();
 var timeStr = now.getHours() + ':' + String(now.getMinutes()).padStart(2, '0');
 sessionResults[type] = {
 html: res.data.result,
 label: typeLabels[type] || type,
 timestamp: timeStr
 };

 $('#f-results').html(res.data.result).show();

 // Update save panel checklist
 if (laaData.isLoggedIn) {
 updateSaveChecklist();
 $('#f-save-panel').slideDown(220);
 } else {
 $('#f-save-panel').show();
 }
 } else {
 showFError(res.data.message || 'Analysis failed.');
 }
 },
 error: function (xhr, status) {
 $('#f-loading').hide();
 showFError(status === 'timeout'
 ? 'Request timed out. Try a shorter document.'
 : 'Connection error. Please try again.');
 }
 });
 });

 // Update save checklist 
 function updateSaveChecklist() {
 var $list = $('#f-save-checklist');
 $list.html('');

 var count = Object.keys(sessionResults).length;
 if (count === 0) return;

 $.each(sessionResults, function (type, data) {
 var checked = 'checked';
 $list.append(
 '<label class="laa-save-check-item">' +
 '<input type="checkbox" class="laa-save-check" value="' + type + '" ' + checked + '> ' +
 '<span class="laa-save-check-label">' + data.label + '</span>' +
 '<span class="laa-save-check-time">' + data.timestamp + '</span>' +
 '</label>'
 );
 });

 // Update counter badge
 $('#f-save-count').text(count + ' ' + (count === 1 ? 'analysis' : 'analyses') + ' available');
 }

 // Save to Dashboard button 
 $(document).on('click', '#f-save-btn', function () {
 var docName = $.trim($('#f-save-name').val());
 var category = $('#f-save-category').val();

 if (!docName) {
 $('#f-save-name').focus();
 showSaveStatus('error', 'Please enter a document name before saving.');
 return;
 }

 // Collect selected analyses
 var selected = {};
 $('.laa-save-check:checked').each(function () {
 var type = $(this).val();
 if (sessionResults[type]) {
 selected[type] = sessionResults[type];
 }
 });

 if (Object.keys(selected).length === 0) {
 showSaveStatus('error', 'Please select at least one analysis to save.');
 return;
 }

 // Check if a save already exists for this document name
 checkExistingSave(docName, function (existingId) {
 if (existingId) {
 // Show replace/append modal
 showConflictModal(docName, existingId, selected, category);
 } else {
 doSave(selected, docName, category, null, 'new');
 }
 });
 });

 // Check if a save already exists for this document name 
 function checkExistingSave(docName, callback) {
 $.ajax({
 url: laaData.ajaxUrl,
 method: 'POST',
 data: {
 action: 'laa_check_existing_save',
 nonce: laaData.nonce,
 doc_name: docName
 },
 success: function (res) {
 callback(res.success && res.data.package_id ? res.data.package_id : null);
 },
 error: function () {
 callback(null);
 }
 });
 }

 // Conflict modal: replace or append 
 function showConflictModal(docName, existingId, selected, category) {
 // Remove any existing modal
 $('#laa-conflict-modal').remove();

 var modal = $(
 '<div id="laa-conflict-modal" class="laa-conflict-overlay">' +
 '<div class="laa-conflict-box">' +
 '<h3>Document Already Saved</h3>' +
 '<p>A saved document named <strong>' + $('<span>').text(docName).html() + '</strong> already exists in your dashboard.</p>' +
 '<p>What would you like to do?</p>' +
 '<div class="laa-conflict-actions">' +
 '<button class="laa-fbtn laa-fbtn-save laa-conflict-append">Add to existing document</button>' +
 '<button class="laa-fbtn laa-conflict-replace">Replace existing document</button>' +
 '<button class="laa-conflict-cancel">Cancel</button>' +
 '</div>' +
 '</div>' +
 '</div>'
 );

 $('body').append(modal);

 modal.find('.laa-conflict-append').on('click', function () {
 modal.remove();
 doSave(selected, docName, category, existingId, 'append');
 });
 modal.find('.laa-conflict-replace').on('click', function () {
 modal.remove();
 doSave(selected, docName, category, existingId, 'replace');
 });
 modal.find('.laa-conflict-cancel').on('click', function () {
 modal.remove();
 });
 modal.on('click', function (e) {
 if ($(e.target).is('#laa-conflict-modal')) modal.remove();
 });
 }

 // Perform the actual save 
 function doSave(selected, docName, category, existingId, mode) {
 var $btn = $('#f-save-btn');
 $btn.prop('disabled', true).find('.laa-save-btn-text').text('Saving...');
 $('#f-save-status').hide();

 // Build ordered HTML bundle: one section per selected analysis
 var bundleHtml = '';
 var typeOrder = ['analyze', 'risks', 'missing', 'dates', 'summary', 'generate'];
 typeOrder.forEach(function (type) {
 if (selected[type]) {
 bundleHtml +=
 '<div class="laa-bundle-section">' +
 '<h2 class="laa-bundle-heading">' + selected[type].label + '</h2>' +
 selected[type].html +
 '</div>';
 }
 });

 var selectedTypes = Object.keys(selected).join(',');

 $.ajax({
 url: laaData.ajaxUrl,
 method: 'POST',
 timeout: 90000,
 data: {
 action: 'laa_save_to_dashboard',
 nonce: laaData.nonce,
 html_result: bundleHtml,
 doc_name: docName,
 category: category,
 analysis_type: selectedTypes,
 existing_id: existingId || '',
 save_mode: mode
 },
 success: function (res) {
 $btn.prop('disabled', false).find('.laa-save-btn-text').text('Save to Dashboard');

 if (res.success) {
 var viewLink = res.data.package_url
 ? ' <a href="' + res.data.package_url + '" target="_blank">View in Dashboard</a>'
 : '';
 var modeLabel = mode === 'append' ? 'Added to' : (mode === 'replace' ? 'Replaced' : 'Saved as');
 showSaveStatus('success',
 modeLabel + ' <strong>' + res.data.filename + '</strong> — ' + res.data.timestamp + '.' + viewLink
 );
 $btn.find('.laa-save-btn-text').text('Saved');
 $btn.addClass('laa-save-btn-saved');
 setTimeout(function () {
 $btn.find('.laa-save-btn-text').text('Save to Dashboard');
 $btn.removeClass('laa-save-btn-saved');
 }, 5000);
 } else {
 showSaveStatus('error', res.data.message || 'Save failed. Please try again.');
 }
 },
 error: function () {
 $btn.prop('disabled', false).find('.laa-save-btn-text').text('Save to Dashboard');
 showSaveStatus('error', 'Connection error. Please try again.');
 }
 });
 }

 // Helpers 
 function showFError(msg) {
 $('#f-loading').hide();
 $('#f-results').html(
 '<div style="background:#fee2e2;border-left:4px solid #800020;border-radius:8px;padding:14px;color:#991b1b;">' +
 '<strong>Error:</strong> ' + msg + '</div>'
 ).show();
 }

 function showSaveStatus(type, msg) {
 var $s = $('#f-save-status');
 $s.removeClass('laa-save-success laa-save-error');
 $s.addClass(type === 'success' ? 'laa-save-success' : 'laa-save-error');
 $s.html(msg).show();
 }

});
