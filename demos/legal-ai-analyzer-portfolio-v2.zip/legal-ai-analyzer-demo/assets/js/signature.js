/**
 * Legal AI Analyzer — Signature Pad
 * Handles draw + type signatures, modal logic, and saving.
 */
jQuery(document).ready(function ($) {

 // State 
 var currentMode = 'draw';
 var currentContractHtml = '';
 var currentContractType = '';
 var canvasA, ctxA, canvasB, ctxB;
 var drawingA = false, drawingB = false;
 var hasSignedA = false, hasSignedB = false;

 // Init canvases 
 function initCanvases() {
 canvasA = document.getElementById('laa-canvas-a');
 canvasB = document.getElementById('laa-canvas-b');
 if (!canvasA || !canvasB) return;
 ctxA = canvasA.getContext('2d');
 ctxB = canvasB.getContext('2d');
 setupCanvas(canvasA, ctxA, 'A');
 setupCanvas(canvasB, ctxB, 'B');
 }

 function setupCanvas(canvas, ctx, party) {
 ctx.strokeStyle = '#1a1a2e';
 ctx.lineWidth = 2.2;
 ctx.lineCap = 'round';
 ctx.lineJoin = 'round';

 // Mouse events
 canvas.addEventListener('mousedown', function(e) { startDraw(e, ctx, party); });
 canvas.addEventListener('mousemove', function(e) { draw(e, ctx, party); });
 canvas.addEventListener('mouseup', function() { stopDraw(party); });
 canvas.addEventListener('mouseleave', function() { stopDraw(party); });

 // Touch events
 canvas.addEventListener('touchstart', function(e) { e.preventDefault(); startDraw(e.touches[0], ctx, party); }, { passive: false });
 canvas.addEventListener('touchmove', function(e) { e.preventDefault(); draw(e.touches[0], ctx, party); }, { passive: false });
 canvas.addEventListener('touchend', function() { stopDraw(party); });
 }

 function getPos(e, canvas) {
 var rect = canvas.getBoundingClientRect();
 var scaleX = canvas.width / rect.width;
 var scaleY = canvas.height / rect.height;
 return {
 x: (e.clientX - rect.left) * scaleX,
 y: (e.clientY - rect.top) * scaleY
 };
 }

 function startDraw(e, ctx, party) {
 var canvas = (party === 'A') ? canvasA : canvasB;
 var pos = getPos(e, canvas);
 ctx.beginPath();
 ctx.moveTo(pos.x, pos.y);
 if (party === 'A') drawingA = true;
 else drawingB = true;
 }

 function draw(e, ctx, party) {
 var isDrawing = (party === 'A') ? drawingA : drawingB;
 if (!isDrawing) return;
 var canvas = (party === 'A') ? canvasA : canvasB;
 var pos = getPos(e, canvas);
 ctx.lineTo(pos.x, pos.y);
 ctx.stroke();
 // Mark as signed and hide hint
 if (party === 'A') { hasSignedA = true; $('#laa-hint-a').hide(); }
 else { hasSignedB = true; $('#laa-hint-b').hide(); }
 }

 function stopDraw(party) {
 if (party === 'A') drawingA = false;
 else drawingB = false;
 }

 // Clear canvas 
 $(document).on('click', '.laa-sign-clear', function () {
 var canvasId = $(this).data('canvas');
 var hintId = $(this).data('hint');
 var canvas = document.getElementById(canvasId);
 var ctx = canvas.getContext('2d');
 ctx.clearRect(0, 0, canvas.width, canvas.height);
 $('#' + hintId).show();
 if (canvasId === 'laa-canvas-a') hasSignedA = false;
 else hasSignedB = false;
 });

 // Mode toggle (draw / type) 
 $(document).on('click', '.laa-sign-tab', function () {
 $('.laa-sign-tab').removeClass('active');
 $(this).addClass('active');
 currentMode = $(this).data('mode');
 if (currentMode === 'draw') {
 $('#laa-sign-draw-mode').show();
 $('#laa-sign-type-mode').hide();
 } else {
 $('#laa-sign-draw-mode').hide();
 $('#laa-sign-type-mode').show();
 }
 });

 // Type mode — live preview 
 $(document).on('input', '#laa-type-a', function () {
 $('#laa-type-preview-a').text($(this).val());
 });
 $(document).on('input', '#laa-type-b', function () {
 $('#laa-type-preview-b').text($(this).val());
 });

 // Convert typed signature to canvas image 
 function typeToDataUrl(text) {
 var offscreen = document.createElement('canvas');
 offscreen.width = 320;
 offscreen.height = 110;
 var ctx = offscreen.getContext('2d');
 ctx.fillStyle = '#ffffff';
 ctx.fillRect(0, 0, 320, 110);
 ctx.font = 'italic 48px Georgia, serif';
 ctx.fillStyle = '#1a1a2e';
 ctx.textBaseline = 'middle';
 ctx.fillText(text, 12, 62);
 return offscreen.toDataURL('image/png');
 }

 // Show sign button after contract is generated 
 // This hooks into the existing frontend.js result display
 $(document).on('laa:contractGenerated', function (e, data) {
 currentContractHtml = data.html || '';
 currentContractType = data.contractType || 'Contract';
 $('#f-sign-section').slideDown(300);
 });

 // Also watch for generate button results — expose via existing flow
 var _origSuccess = window.laaOnGenerateSuccess;
 $(document).on('laa:resultShown', function (e, type, html) {
 if (type === 'generate') {
 currentContractHtml = html;
 currentContractType = 'Contract';
 $('#f-sign-section').slideDown(300);
 }
 });

 // Open modal 
 $(document).on('click', '#f-open-sign-modal', function () {
 resetModal();
 $('#laa-sign-modal').fadeIn(220);
 $('body').addClass('laa-modal-open');
 setTimeout(initCanvases, 100);
 });

 // Close modal 
 function closeModal() {
 $('#laa-sign-modal').fadeOut(200);
 $('body').removeClass('laa-modal-open');
 }

 $(document).on('click', '#laa-sign-close, #laa-sign-cancel, #laa-sign-done', closeModal);

 // Close on overlay click
 $(document).on('click', '#laa-sign-modal', function (e) {
 if ($(e.target).is('#laa-sign-modal')) closeModal();
 });

 // Close on Escape
 $(document).on('keydown', function (e) {
 if (e.key === 'Escape') closeModal();
 });

 // Reset modal state 
 function resetModal() {
 $('#laa-sign-name-a, #laa-sign-email-a, #laa-sign-name-b, #laa-sign-email-b').val('');
 $('#laa-type-a, #laa-type-b').val('');
 $('#laa-type-preview-a, #laa-type-preview-b').text('');
 $('#laa-hint-a, #laa-hint-b').show();
 $('#laa-sign-error').hide().text('');
 $('#laa-sign-loading').hide();
 $('#laa-sign-success').hide();
 $('#laa-sign-actions, .laa-sign-parties, .laa-sign-toggle, #laa-sign-draw-mode, .laa-sign-notice').show();
 hasSignedA = false;
 hasSignedB = false;
 currentMode = 'draw';
 $('.laa-sign-tab').removeClass('active');
 $('[data-mode="draw"]').addClass('active');
 $('#laa-sign-draw-mode').show();
 $('#laa-sign-type-mode').hide();
 }

 // Submit 
 $(document).on('click', '#laa-sign-submit', function () {
 var nameA = $.trim($('#laa-sign-name-a').val());
 var nameB = $.trim($('#laa-sign-name-b').val());
 var emailA = $.trim($('#laa-sign-email-a').val());
 var emailB = $.trim($('#laa-sign-email-b').val());

 // Validation
 if (!nameA || !nameB) {
 showSignError('Please enter full legal names for both parties.');
 return;
 }

 var sigDataA, sigDataB;

 if (currentMode === 'draw') {
 if (!hasSignedA || !hasSignedB) {
 showSignError('Both parties must draw their signature before submitting.');
 return;
 }
 sigDataA = canvasA.toDataURL('image/png');
 sigDataB = canvasB.toDataURL('image/png');
 } else {
 var typeA = $.trim($('#laa-type-a').val());
 var typeB = $.trim($('#laa-type-b').val());
 if (!typeA || !typeB) {
 showSignError('Both parties must type their name to sign.');
 return;
 }
 sigDataA = typeToDataUrl(typeA);
 sigDataB = typeToDataUrl(typeB);
 }

 if (!currentContractHtml) {
 showSignError('No contract content found. Please generate a contract first.');
 return;
 }

 // Show loading
 $('#laa-sign-error').hide();
 $('#laa-sign-actions, .laa-sign-parties, .laa-sign-toggle, #laa-sign-draw-mode, #laa-sign-type-mode, .laa-sign-notice').hide();
 $('#laa-sign-loading').show();

 $.ajax({
 url: laaData.ajaxUrl,
 method: 'POST',
 timeout: 90000,
 data: {
 action: 'laa_save_signed_contract',
 nonce: laaData.nonce,
 contract_html: currentContractHtml,
 contract_type: currentContractType,
 signature_a: sigDataA,
 signature_b: sigDataB,
 name_a: nameA,
 name_b: nameB,
 email_a: emailA,
 email_b: emailB,
 },
 success: function (res) {
 $('#laa-sign-loading').hide();
 if (res.success) {
 showSignSuccess(res.data);
 } else {
 showSignFormAgain();
 showSignError(res.data.message || 'Save failed. Please try again.');
 }
 },
 error: function () {
 $('#laa-sign-loading').hide();
 showSignFormAgain();
 showSignError('Connection error. Please try again.');
 }
 });
 });

 function showSignFormAgain() {
 $('#laa-sign-actions, .laa-sign-parties, .laa-sign-toggle, .laa-sign-notice').show();
 if (currentMode === 'draw') $('#laa-sign-draw-mode').show();
 else $('#laa-sign-type-mode').show();
 }

 function showSignSuccess(data) {
 $('#laa-sign-success-msg').text(
 'Your signed contract "' + data.doc_name + '" has been saved to your document library.' +
 (data.emails ? ' Both parties have been notified by email.' : '')
 );
 if (data.package_url) {
 $('#laa-sign-success-link').attr('href', data.package_url).show();
 }
 $('#laa-sign-success').show();
 // Also update the sign button on the page
 $('#f-open-sign-modal').text(' Contract Signed').prop('disabled', true).addClass('laa-fbtn-signed');
 }

 function showSignError(msg) {
 $('#laa-sign-error').text(msg).show();
 }

});

// Hook into existing frontend.js to detect when a contract is generated 
// Patch the existing AJAX success to fire our custom event
(function ($) {
 $(document).ajaxSuccess(function (event, xhr, settings, data) {
 try {
 if (settings.data && typeof settings.data === 'string' &&
 settings.data.indexOf('analysis_type=generate') !== -1 &&
 data && data.success && data.data && data.data.result) {
 $(document).trigger('laa:resultShown', ['generate', data.data.result]);
 }
 } catch(e) {}
 });
})(jQuery);
