jQuery(document).ready(function ($) {

 // State: extracted PDF text per tab 
 var pdfTextStore = {}; // { 'analyze': '...text...', 'risks': '...', ... }

 // Tab switching 
 $('.laa-tab').on('click', function () {
 $('.laa-tab').removeClass('active');
 $(this).addClass('active');
 $('.laa-tab-content').removeClass('active');
 $('#tab-' + $(this).data('tab')).addClass('active');
 });

 // PDF upload zones: browse button 
 $(document).on('click', '.laa-pdf-browse-btn', function () {
 var inputId = $(this).data('input');
 $('#' + inputId).trigger('click');
 });

 // PDF file input change 
 $(document).on('change', '.laa-pdf-input', function () {
 var file = this.files[0];
 var tabId = $(this).closest('.laa-pdf-zone').data('tab');
 if (file) handlePdfFile(file, tabId);
 });

 // Drag and drop 
 $(document).on('dragover dragenter', '.laa-pdf-drop', function (e) {
 e.preventDefault();
 e.stopPropagation();
 $(this).addClass('laa-drag-over');
 });

 $(document).on('dragleave', '.laa-pdf-drop', function (e) {
 e.preventDefault();
 $(this).removeClass('laa-drag-over');
 });

 $(document).on('drop', '.laa-pdf-drop', function (e) {
 e.preventDefault();
 e.stopPropagation();
 $(this).removeClass('laa-drag-over');
 var tabId = $(this).closest('.laa-pdf-zone').data('tab');
 var file = e.originalEvent.dataTransfer.files[0];
 if (file) {
 if (file.type !== 'application/pdf' && !file.name.match(/\.pdf$/i)) {
 showPdfError(tabId, 'Only PDF files are accepted.');
 return;
 }
 handlePdfFile(file, tabId);
 }
 });

 // Remove PDF 
 $(document).on('click', '.laa-pdf-remove-btn', function () {
 var tabId = $(this).data('tab');
 clearPdf(tabId);
 });

 // Upload and extract PDF 
 function handlePdfFile(file, tabId) {
 if (file.size > 10 * 1024 * 1024) {
 showPdfError(tabId, 'PDF must be under 10MB.');
 return;
 }

 // Show loading state
 $('#pdf-drop-' + tabId).hide();
 $('#pdf-status-' + tabId).hide();
 $('#pdf-loading-' + tabId).show();

 var formData = new FormData();
 formData.append('action', 'laa_extract_pdf');
 formData.append('nonce', laaData.nonce);
 formData.append('pdf_file', file);

 $.ajax({
 url: laaData.ajaxUrl,
 method: 'POST',
 data: formData,
 processData: false,
 contentType: false,
 timeout: 60000,
 success: function (res) {
 $('#pdf-loading-' + tabId).hide();
 if (res.success) {
 pdfTextStore[tabId] = res.data.text;
 $('#pdf-filename-' + tabId).text(res.data.filename);
 $('#pdf-filesummary-' + tabId).text('— ' + res.data.summary);
 $('#pdf-status-' + tabId).show();

 if (res.data.truncated) {
 showPdfWarning(tabId, 'Large document: only the first 80,000 characters were extracted.');
 }

 // Clear the textarea since PDF is loaded
 var textareaId = tabId + '-text';
 $('#' + textareaId).val('').attr('placeholder', ' PDF loaded — click Analyse, or paste text below to override');
 } else {
 $('#pdf-drop-' + tabId).show();
 showPdfError(tabId, res.data.message || 'PDF extraction failed.');
 }
 },
 error: function (xhr, status) {
 $('#pdf-loading-' + tabId).hide();
 $('#pdf-drop-' + tabId).show();
 var msg = status === 'timeout'
 ? 'Upload timed out. Try a smaller file.'
 : 'Upload failed. Please try again.';
 showPdfError(tabId, msg);
 }
 });
 }

 function clearPdf(tabId) {
 delete pdfTextStore[tabId];
 $('#pdf-input-' + tabId).val('');
 $('#pdf-status-' + tabId).hide();
 $('#pdf-loading-' + tabId).hide();
 $('#pdf-drop-' + tabId).show();
 // Reset textarea placeholder
 var textareaId = tabId + '-text';
 $('#' + textareaId).val('').attr('placeholder', getDefaultPlaceholder(tabId));
 }

 function showPdfError(tabId, msg) {
 var zone = $('#pdf-zone-' + tabId);
 zone.find('.laa-pdf-error').remove();
 zone.append('<p class="laa-pdf-error"> ' + msg + '</p>');
 setTimeout(function () { zone.find('.laa-pdf-error').fadeOut(400, function () { $(this).remove(); }); }, 5000);
 }

 function showPdfWarning(tabId, msg) {
 var zone = $('#pdf-zone-' + tabId);
 zone.find('.laa-pdf-warning').remove();
 zone.append('<p class="laa-pdf-warning"> ' + msg + '</p>');
 }

 function getDefaultPlaceholder(tabId) {
 var placeholders = {
 'analyze': 'Paste your legal document here...',
 'risks': 'Paste your contract to assess risks...',
 'missing': 'Paste your contract to detect missing clauses...',
 'dates': 'Paste your document to extract key dates...',
 'summary': 'Paste your legal document for a plain-language summary...'
 };
 return placeholders[tabId] || 'Paste document text here...';
 }

 // Main analysis button handler 
 $(document).on('click', '.laa-btn[data-type]', function () {
 var type = $(this).data('type');
 var textareaId = $(this).data('text-id') || (type + '-text');
 var documentText = '';
 var contractType = '';
 var contractDetails = '';

 if (type === 'generate') {
 var formData = window.laaCollectGenerateForm('');
 contractType = formData.contractType;
 contractDetails = formData.details;
 if (!contractDetails.trim()) {
 showError('Please fill in at least the party names and key details.');
 return;
 }
 } else {
 // Priority: PDF text > textarea text
 if (pdfTextStore[type] && pdfTextStore[type].trim()) {
 documentText = pdfTextStore[type];
 } else {
 documentText = $('#' + textareaId).val();
 }

 if (!documentText.trim()) {
 showError('Please upload a PDF or paste document text before analysing.');
 return;
 }
 }

 var source = pdfTextStore[type] ? 'PDF' : 'text';
 showLoading(type, source);

 $.ajax({
 url: laaData.ajaxUrl,
 method: 'POST',
 timeout: 180000,
 data: {
 action: 'laa_analyze_document',
 nonce: laaData.nonce,
 analysis_type: type,
 document_text: documentText,
 contract_type: contractType,
 contract_details: contractDetails,
 pdf_filename: $('#pdf-filename-' + type).text() || ''
 },
 success: function (res) {
 if (res.success) {
 showResults(res.data.result);
 } else {
 showError(res.data.message || 'Analysis failed. Please try again.');
 }
 },
 error: function (xhr, status) {
 var msg = status === 'timeout'
 ? 'Request timed out. The document may be very long — try a shorter section.'
 : 'Connection error. Please check your internet connection.';
 showError(msg);
 }
 });
 });

 // UI helpers 
 function showLoading(type, source) {
 $('#laa-placeholder').hide();
 $('#laa-results').hide();
 $('#results-actions').hide();
 var sourceLabel = source === 'PDF' ? 'Analysing PDF via AI Engine...' : 'Analysing via AI Engine...';
 $('#loading-main-text').text(sourceLabel);
 $('#loading-sub-text').text('This may take 15–30 seconds for complex documents');
 $('#laa-loading').show();
 }

 function showResults(html) {
 $('#laa-loading').hide();
 $('#laa-placeholder').hide();
 $('#laa-results').html(html).show();
 $('#results-actions').show();
 // Scroll results into view
 $('html, body').animate({ scrollTop: $('#laa-results').offset().top - 30 }, 300);
 }

 function showError(msg) {
 $('#laa-loading').hide();
 $('#laa-placeholder').hide();
 $('#laa-results').html(
 '<div style="background:#fee2e2;border-left:4px solid #dc2626;border-radius:8px;padding:16px 20px;color:#991b1b;">' +
 '<strong> Error:</strong> ' + msg + '</div>'
 ).show();
 }

 // Copy results 
 $('#copy-results').on('click', function () {
 var text = $('#laa-results').text();
 navigator.clipboard.writeText(text).then(function () {
 var btn = $('#copy-results');
 var orig = btn.text();
 btn.text(' Copied!');
 setTimeout(function () { btn.text(orig); }, 2000);
 });
 });

 // Print results 
 $('#print-results').on('click', function () {
 var content = $('#laa-results').html();
 var win = window.open('', '_blank');
 win.document.write(
 '<html><head><title>Legal AI Analysis</title>' +
 '<style>body{font-family:Georgia,serif;max-width:900px;margin:40px auto;padding:0 20px;line-height:1.7;color:#222;}' +
 'h3{font-size:18px;margin-top:28px;color:#1a1a2e;} ' +
 '.laa-section{margin-bottom:24px;padding:16px 20px;background:#faf8f3;border-radius:8px;border:1px solid #e5e0d5;}' +
 'table{width:100%;border-collapse:collapse;font-size:14px;}' +
 'th{background:#1a1a2e;color:#c9a84c;padding:8px 12px;text-align:left;}' +
 'td{padding:8px 12px;border-bottom:1px solid #e5e0d5;}' +
 '</style></head><body>' + content + '</body></html>'
 );
 win.document.close();
 win.print();
 });

});
