<?php
/**
 * Generate Contract — form field definitions.
 * Returns an array of field sets keyed by contract type.
 * Each field: [ id, label, type (text|textarea|select|date), options (for select), placeholder, required ]
 */
if (!defined('ABSPATH')) exit;

function laa_get_generate_form_fields() {
    $common_parties = [
        [ 'id' => 'party_a_name',    'label' => 'Party A — Full Legal Name',    'type' => 'text',     'placeholder' => 'e.g. Acme Ltd',           'required' => true ],
        [ 'id' => 'party_a_address', 'label' => 'Party A — Registered Address', 'type' => 'text',     'placeholder' => 'e.g. 12 High Street, London, EC1A 1BB', 'required' => false ],
        [ 'id' => 'party_b_name',    'label' => 'Party B — Full Legal Name',    'type' => 'text',     'placeholder' => 'e.g. Smith Consulting Ltd', 'required' => true ],
        [ 'id' => 'party_b_address', 'label' => 'Party B — Registered Address', 'type' => 'text',     'placeholder' => 'e.g. 45 Park Lane, Manchester, M1 2AB', 'required' => false ],
        [ 'id' => 'governing_law',   'label' => 'Governing Law & Jurisdiction', 'type' => 'select',   'required' => true, 'options' => [
            'England and Wales', 'Scotland', 'Northern Ireland', 'Other (specify below)'
        ]],
        [ 'id' => 'start_date',      'label' => 'Contract Start Date',          'type' => 'date',     'placeholder' => '',                          'required' => false ],
    ];

    return [

        'Service Agreement' => array_merge($common_parties, [
            [ 'id' => 'services_description', 'label' => 'Description of Services',      'type' => 'textarea', 'placeholder' => 'Describe the services to be provided in detail...', 'required' => true ],
            [ 'id' => 'deliverables',         'label' => 'Key Deliverables',             'type' => 'textarea', 'placeholder' => 'List the specific deliverables and outputs expected...', 'required' => false ],
            [ 'id' => 'fee_amount',           'label' => 'Fee Amount (£)',               'type' => 'text',     'placeholder' => 'e.g. 5,000', 'required' => false ],
            [ 'id' => 'fee_structure',        'label' => 'Fee Structure',                'type' => 'select',   'required' => false, 'options' => [
                'Fixed fee', 'Hourly rate', 'Monthly retainer', 'Milestone-based', 'Other'
            ]],
            [ 'id' => 'payment_terms',        'label' => 'Payment Terms',                'type' => 'select',   'required' => false, 'options' => [
                '14 days', '30 days', '60 days', 'On completion', 'In advance', 'Other'
            ]],
            [ 'id' => 'duration',             'label' => 'Contract Duration',            'type' => 'text',     'placeholder' => 'e.g. 6 months, 1 year, ongoing', 'required' => false ],
            [ 'id' => 'notice_period',        'label' => 'Notice Period for Termination','type' => 'select',   'required' => false, 'options' => [
                '7 days', '14 days', '1 month', '3 months', 'Other'
            ]],
            [ 'id' => 'special_terms',        'label' => 'Any Special Terms or Notes',   'type' => 'textarea', 'placeholder' => 'Any additional requirements, restrictions, or special conditions...', 'required' => false ],
        ]),

        'Employment Contract' => array_merge($common_parties, [
            [ 'id' => 'employee_job_title',   'label' => 'Job Title',                   'type' => 'text',     'placeholder' => 'e.g. Senior Software Engineer', 'required' => true ],
            [ 'id' => 'employee_department',  'label' => 'Department',                  'type' => 'text',     'placeholder' => 'e.g. Engineering', 'required' => false ],
            [ 'id' => 'place_of_work',        'label' => 'Place of Work',               'type' => 'text',     'placeholder' => 'e.g. London office / Remote / Hybrid', 'required' => false ],
            [ 'id' => 'salary',               'label' => 'Annual Salary (£)',           'type' => 'text',     'placeholder' => 'e.g. 45,000', 'required' => true ],
            [ 'id' => 'pay_frequency',        'label' => 'Pay Frequency',               'type' => 'select',   'required' => false, 'options' => [
                'Monthly', 'Bi-weekly', 'Weekly'
            ]],
            [ 'id' => 'hours_per_week',       'label' => 'Hours Per Week',              'type' => 'text',     'placeholder' => 'e.g. 37.5', 'required' => false ],
            [ 'id' => 'holiday_entitlement',  'label' => 'Holiday Entitlement (days)',  'type' => 'text',     'placeholder' => 'e.g. 25 days plus bank holidays', 'required' => false ],
            [ 'id' => 'probation_period',     'label' => 'Probationary Period',         'type' => 'select',   'required' => false, 'options' => [
                'None', '1 month', '3 months', '6 months'
            ]],
            [ 'id' => 'notice_period',        'label' => 'Notice Period',               'type' => 'select',   'required' => false, 'options' => [
                '1 week', '1 month', '3 months', '6 months', 'Statutory minimum only'
            ]],
            [ 'id' => 'benefits',             'label' => 'Benefits',                    'type' => 'textarea', 'placeholder' => 'e.g. Pension (5% employer), private health, laptop...', 'required' => false ],
            [ 'id' => 'restrictive_covenants','label' => 'Restrictive Covenants',       'type' => 'textarea', 'placeholder' => 'e.g. 6-month non-compete within the UK...', 'required' => false ],
        ]),

        'Non-Disclosure Agreement (NDA)' => array_merge($common_parties, [
            [ 'id' => 'nda_type',             'label' => 'NDA Type',                    'type' => 'select',   'required' => true, 'options' => [
                'Mutual (both parties)', 'One-way (disclosing to receiving party only)'
            ]],
            [ 'id' => 'purpose',              'label' => 'Purpose of Disclosure',       'type' => 'textarea', 'placeholder' => 'e.g. Evaluation of a potential business partnership regarding...', 'required' => true ],
            [ 'id' => 'confidential_info',    'label' => 'What Counts as Confidential', 'type' => 'textarea', 'placeholder' => 'e.g. Financial data, trade secrets, technical specifications, customer lists...', 'required' => false ],
            [ 'id' => 'duration',             'label' => 'Confidentiality Duration',    'type' => 'select',   'required' => false, 'options' => [
                '1 year', '2 years', '3 years', '5 years', 'Indefinite'
            ]],
            [ 'id' => 'permitted_disclosure', 'label' => 'Permitted Disclosures',       'type' => 'textarea', 'placeholder' => 'e.g. May be shared with employees on a need-to-know basis...', 'required' => false ],
        ]),

        'Independent Contractor Agreement' => array_merge($common_parties, [
            [ 'id' => 'services_description', 'label' => 'Services to be Provided',     'type' => 'textarea', 'placeholder' => 'Describe the work and services the contractor will provide...', 'required' => true ],
            [ 'id' => 'rate',                 'label' => 'Rate of Pay',                 'type' => 'text',     'placeholder' => 'e.g. £500/day or £75/hour', 'required' => true ],
            [ 'id' => 'payment_terms',        'label' => 'Payment Terms',               'type' => 'select',   'required' => false, 'options' => [
                '14 days', '30 days', 'On completion', 'Milestone-based'
            ]],
            [ 'id' => 'duration',             'label' => 'Contract Duration',           'type' => 'text',     'placeholder' => 'e.g. 3 months, until project completion', 'required' => false ],
            [ 'id' => 'ir35_status',          'label' => 'IR35 Status',                 'type' => 'select',   'required' => false, 'options' => [
                'Outside IR35', 'Inside IR35', 'Not yet determined'
            ]],
            [ 'id' => 'ip_ownership',         'label' => 'IP / Work Product Ownership', 'type' => 'select',   'required' => false, 'options' => [
                'Client owns all work product', 'Contractor retains IP, grants licence', 'Shared ownership'
            ]],
            [ 'id' => 'notice_period',        'label' => 'Notice Period',               'type' => 'select',   'required' => false, 'options' => [
                '1 week', '2 weeks', '1 month', 'None'
            ]],
            [ 'id' => 'special_terms',        'label' => 'Special Terms or Notes',      'type' => 'textarea', 'placeholder' => 'Any additional requirements...', 'required' => false ],
        ]),

        'Software Licence Agreement' => array_merge($common_parties, [
            [ 'id' => 'software_name',        'label' => 'Software / Product Name',     'type' => 'text',     'placeholder' => 'e.g. Acme CRM Platform', 'required' => true ],
            [ 'id' => 'licence_type',         'label' => 'Licence Type',                'type' => 'select',   'required' => true, 'options' => [
                'Perpetual licence', 'Subscription (annual)', 'Subscription (monthly)', 'Site licence', 'Per-user licence'
            ]],
            [ 'id' => 'licence_fee',          'label' => 'Licence Fee (£)',             'type' => 'text',     'placeholder' => 'e.g. 1,200/year or 100/month', 'required' => false ],
            [ 'id' => 'permitted_users',      'label' => 'Permitted Users / Scope',     'type' => 'text',     'placeholder' => 'e.g. Up to 10 named users within one organisation', 'required' => false ],
            [ 'id' => 'restrictions',         'label' => 'Use Restrictions',            'type' => 'textarea', 'placeholder' => 'e.g. No sublicensing, no reverse engineering, internal use only...', 'required' => false ],
            [ 'id' => 'support_level',        'label' => 'Support & Maintenance',       'type' => 'select',   'required' => false, 'options' => [
                'None included', 'Email support only', 'Business hours support', '24/7 support'
            ]],
            [ 'id' => 'special_terms',        'label' => 'Additional Terms',            'type' => 'textarea', 'placeholder' => 'SLAs, data processing terms, update obligations...', 'required' => false ],
        ]),

        'Partnership Agreement' => array_merge($common_parties, [
            [ 'id' => 'partnership_name',     'label' => 'Partnership / Business Name', 'type' => 'text',     'placeholder' => 'e.g. Smith & Jones Partners', 'required' => false ],
            [ 'id' => 'business_purpose',     'label' => 'Business Purpose',            'type' => 'textarea', 'placeholder' => 'Describe the nature and purpose of the partnership...', 'required' => true ],
            [ 'id' => 'profit_split',         'label' => 'Profit & Loss Split',         'type' => 'text',     'placeholder' => 'e.g. 50/50, or Party A 60% / Party B 40%', 'required' => true ],
            [ 'id' => 'capital_contribution', 'label' => 'Capital Contributions',       'type' => 'textarea', 'placeholder' => 'e.g. Party A contributes £10,000; Party B contributes IP and equipment', 'required' => false ],
            [ 'id' => 'decision_making',      'label' => 'Decision-Making Process',     'type' => 'select',   'required' => false, 'options' => [
                'Unanimous consent required', 'Majority vote', 'Managing partner decides', 'Other'
            ]],
            [ 'id' => 'duration',             'label' => 'Partnership Duration',        'type' => 'select',   'required' => false, 'options' => [
                'Indefinite', 'Fixed term (specify in notes)', 'Until project completion'
            ]],
            [ 'id' => 'exit_provisions',      'label' => 'Exit & Dissolution Terms',    'type' => 'textarea', 'placeholder' => 'How can a partner exit? What happens to assets on dissolution?', 'required' => false ],
        ]),

        'Consultancy Agreement' => array_merge($common_parties, [
            [ 'id' => 'services_description', 'label' => 'Consultancy Services',        'type' => 'textarea', 'placeholder' => 'Describe the consultancy services and areas of expertise required...', 'required' => true ],
            [ 'id' => 'fee_amount',           'label' => 'Fee / Rate',                  'type' => 'text',     'placeholder' => 'e.g. £1,500/day or £10,000/month', 'required' => true ],
            [ 'id' => 'payment_terms',        'label' => 'Payment Terms',               'type' => 'select',   'required' => false, 'options' => [
                '14 days', '30 days', 'Monthly in advance', 'On completion'
            ]],
            [ 'id' => 'duration',             'label' => 'Engagement Duration',         'type' => 'text',     'placeholder' => 'e.g. 12 months, ongoing', 'required' => false ],
            [ 'id' => 'exclusivity',          'label' => 'Exclusivity',                 'type' => 'select',   'required' => false, 'options' => [
                'Non-exclusive (consultant may work for others)', 'Exclusive within sector', 'Fully exclusive'
            ]],
            [ 'id' => 'confidentiality',      'label' => 'Confidentiality Requirements','type' => 'textarea', 'placeholder' => 'Specify any particular confidentiality requirements...', 'required' => false ],
            [ 'id' => 'notice_period',        'label' => 'Notice Period',               'type' => 'select',   'required' => false, 'options' => [
                '2 weeks', '1 month', '3 months', 'None'
            ]],
        ]),

        'Terms of Service' => array_merge([
            [ 'id' => 'business_name',        'label' => 'Business / Company Name',     'type' => 'text',     'placeholder' => 'e.g. Acme Ltd', 'required' => true ],
            [ 'id' => 'website_url',          'label' => 'Website URL',                 'type' => 'text',     'placeholder' => 'e.g. https://www.example.com', 'required' => false ],
        ], [
            [ 'id' => 'service_description',  'label' => 'What Your Service Does',      'type' => 'textarea', 'placeholder' => 'Describe what your platform/service provides to users...', 'required' => true ],
            [ 'id' => 'user_obligations',     'label' => 'User Obligations & Rules',    'type' => 'textarea', 'placeholder' => 'e.g. No spam, no illegal content, must be 18+...', 'required' => false ],
            [ 'id' => 'payment_terms',        'label' => 'Payment / Subscription Terms','type' => 'textarea', 'placeholder' => 'e.g. Monthly subscription, no refunds after 14 days...', 'required' => false ],
            [ 'id' => 'ip_ownership',         'label' => 'Intellectual Property',       'type' => 'select',   'required' => false, 'options' => [
                'Company retains all IP', 'User retains IP in their content', 'Shared / licensed'
            ]],
            [ 'id' => 'governing_law',        'label' => 'Governing Law',               'type' => 'select',   'required' => true, 'options' => [
                'England and Wales', 'Scotland', 'Northern Ireland', 'Other'
            ]],
            [ 'id' => 'special_terms',        'label' => 'Additional Clauses or Notes', 'type' => 'textarea', 'placeholder' => 'Any other specific rules, limitations, or provisions...', 'required' => false ],
        ]),

    ];
}
