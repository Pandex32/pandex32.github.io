<?php
/**
 * LAA PDF Text Extractor
 * Lightweight, dependency-free PDF text extraction for WordPress.
 * Extracts readable text from PDF files using native PHP string parsing.
 */

if (!defined('ABSPATH')) exit;

class LAA_PDF_Extractor {

    /**
     * Extract text from a PDF file path.
     * Returns extracted text string, or WP_Error on failure.
     */
    public static function extract($file_path) {
        if (!file_exists($file_path)) {
            return new WP_Error('pdf_not_found', 'PDF file not found.');
        }

        $size = filesize($file_path);
        if ($size === 0) {
            return new WP_Error('pdf_empty', 'The PDF file is empty.');
        }
        if ($size > 10 * 1024 * 1024) { // 10MB limit
            return new WP_Error('pdf_too_large', 'PDF file is too large (max 10MB). Please use a smaller file or paste the text directly.');
        }

        $content = file_get_contents($file_path);
        if ($content === false) {
            return new WP_Error('pdf_read_error', 'Could not read the PDF file.');
        }

        // Verify it's actually a PDF
        if (substr($content, 0, 4) !== '%PDF') {
            return new WP_Error('pdf_invalid', 'The uploaded file does not appear to be a valid PDF.');
        }

        $text = self::parse($content);

        if (empty(trim($text))) {
            return new WP_Error('pdf_no_text', 'Could not extract text from this PDF. It may be a scanned image PDF. Please copy and paste the text manually.');
        }

        return $text;
    }

    /**
     * Core PDF text parsing — extracts text from PDF content streams.
     */
    private static function parse($content) {
        $text = '';

        // Decompress any zlib/deflate compressed streams
        $content = self::decompress_streams($content);

        // Extract all text from BT...ET blocks (PDF text objects)
        $text .= self::extract_bt_blocks($content);

        // Also grab any loose text strings not in BT blocks
        if (strlen(trim($text)) < 100) {
            $text .= self::extract_loose_strings($content);
        }

        // Clean up the extracted text
        $text = self::clean_text($text);

        return $text;
    }

    /**
     * Decompress zlib-compressed PDF streams so text is readable.
     */
    private static function decompress_streams($content) {
        // Find FlateDecode streams and decompress them
        $result = preg_replace_callback(
            '/stream\r?\n(.*?)\r?\nendstream/s',
            function ($matches) {
                $stream = $matches[1];
                // Try to decompress
                $decompressed = @gzuncompress($stream);
                if ($decompressed === false) {
                    $decompressed = @gzinflate($stream);
                }
                if ($decompressed === false) {
                    $decompressed = @gzdecode($stream);
                }
                return $decompressed !== false ? $decompressed : $matches[0];
            },
            $content
        );
        return $result ?: $content;
    }

    /**
     * Extract text from PDF BT (Begin Text) ... ET (End Text) blocks.
     * This is where most readable text in PDFs lives.
     */
    private static function extract_bt_blocks($content) {
        $text = '';

        // Match BT...ET blocks
        preg_match_all('/BT\s+(.*?)\s+ET/s', $content, $blocks);

        foreach ($blocks[1] as $block) {
            $block_text = '';

            // Handle Tj operator — single string: (text) Tj
            preg_match_all('/\(((?:[^()\\\\]|\\\\.)*)\ *\)\s*Tj/s', $block, $tj_matches);
            foreach ($tj_matches[1] as $match) {
                $block_text .= self::decode_pdf_string($match) . ' ';
            }

            // Handle TJ operator — array of strings: [(text)(more)] TJ
            preg_match_all('/\[(.*?)\]\s*TJ/s', $block, $tj_array_matches);
            foreach ($tj_array_matches[1] as $array_content) {
                preg_match_all('/\(((?:[^()\\\\]|\\\\.)*)\)/', $array_content, $string_matches);
                foreach ($string_matches[1] as $str) {
                    $decoded = self::decode_pdf_string($str);
                    if ($decoded !== '') {
                        $block_text .= $decoded;
                    }
                }
                $block_text .= ' ';
            }

            // Handle ' and " operators (move to next line and show text)
            preg_match_all('/\(((?:[^()\\\\]|\\.)*)\)\s*[\'"]/', $block, $quote_matches);
            foreach ($quote_matches[1] as $match) {
                $block_text .= "\n" . self::decode_pdf_string($match);
            }

            // Add Td/TD/T* line breaks
            $block_text = preg_replace('/\s+T[dD*]\s+/', "\n", $block_text);

            if (trim($block_text) !== '') {
                $text .= $block_text . "\n";
            }
        }

        return $text;
    }

    /**
     * Fallback: extract loose parenthesized strings from the PDF.
     */
    private static function extract_loose_strings($content) {
        $text = '';
        preg_match_all('/\(((?:[^()\\\\]|\\\\.){3,})\)/', $content, $matches);
        foreach ($matches[1] as $match) {
            $decoded = self::decode_pdf_string($match);
            // Only keep strings that look like real readable text
            if (self::looks_like_text($decoded)) {
                $text .= $decoded . ' ';
            }
        }
        return $text;
    }

    /**
     * Decode a PDF string — handles octal escapes, hex encoding, and common PDF encodings.
     */
    private static function decode_pdf_string($str) {
        // Handle octal escape sequences like \101 = A
        $str = preg_replace_callback('/\\\\([0-7]{1,3})/', function ($m) {
            return chr(octdec($m[1]));
        }, $str);

        // Handle standard escape sequences
        $escapes = [
            '\\n' => "\n", '\\r' => "\r", '\\t' => "\t",
            '\\b' => "\x08", '\\f' => "\x0C",
            '\\(' => '(', '\\)' => ')', '\\\\' => '\\'
        ];
        $str = str_replace(array_keys($escapes), array_values($escapes), $str);

        // Try UTF-16BE decode (common in PDFs with unicode)
        if (strlen($str) >= 2 && substr($str, 0, 2) === "\xFE\xFF") {
            $str = mb_convert_encoding(substr($str, 2), 'UTF-8', 'UTF-16BE');
        }

        // Remove non-printable characters except common whitespace
        $str = preg_replace('/[\x00-\x08\x0B\x0C\x0E-\x1F\x7F]/', '', $str);

        return $str;
    }

    /**
     * Check if a string looks like human-readable text (not binary data).
     */
    private static function looks_like_text($str) {
        if (strlen($str) < 3) return false;
        // Count printable ASCII characters
        $printable = preg_match_all('/[\x20-\x7E]/', $str);
        $ratio = $printable / max(strlen($str), 1);
        return $ratio > 0.7; // At least 70% printable chars
    }

    /**
     * Clean up extracted text — normalize whitespace, remove junk.
     */
    private static function clean_text($text) {
        // Normalize line endings
        $text = str_replace(["\r\n", "\r"], "\n", $text);

        // Remove PDF operator remnants
        $text = preg_replace('/\b(BT|ET|Tf|Tm|Td|TD|Tr|Ts|Tc|Tw|Tz|TL|T\*|cm|re|f|S|q|Q|gs|Do|BMC|EMC|BDC|scn|SCN|rg|RG|w|J|j|M|d|ri|i|cs|CS|sh|W)\b/', '', $text);

        // Remove hex strings
        $text = preg_replace('/<[0-9A-Fa-f\s]+>/', '', $text);

        // Remove lines that are just numbers/coordinates (PDF graphics operators)
        $text = preg_replace('/^[\s\d\.\-]+$/m', '', $text);

        // Collapse multiple spaces
        $text = preg_replace('/[ \t]{2,}/', ' ', $text);

        // Collapse excessive newlines
        $text = preg_replace('/\n{3,}/', "\n\n", $text);

        // Remove very short lines (likely artefacts)
        $lines = explode("\n", $text);
        $lines = array_filter($lines, function($line) {
            return strlen(trim($line)) > 2;
        });

        return trim(implode("\n", $lines));
    }
}
