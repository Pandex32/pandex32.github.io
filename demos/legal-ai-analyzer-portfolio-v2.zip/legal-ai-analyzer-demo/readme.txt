=== Legal AI Analyzer (AI Engine) ===
Contributors: Dylan Osei-Afriyie
Tags: legal, ai, contract, analysis, ai-engine, openai, claude, gemini
Requires at least: 5.8
Tested up to: 6.7
Requires PHP: 7.4
Stable tag: 1.0.0
License: GPLv2 or later

AI-powered legal document analyzer — powered by AI Engine. Supports OpenAI, Claude, Gemini, and more.

== Description ==

Legal AI Analyzer uses the AI Engine plugin as its AI layer, meaning you can power it with ANY model AI Engine supports — OpenAI, Anthropic Claude, Google Gemini, Mistral, OpenRouter, and more.

**Requires:** AI Engine plugin (free, by Jordy Meow) — https://wordpress.org/plugins/ai-engine/

**Features:**
* Full Contract Analysis — Overview, risks, missing clauses, dates, recommendations
* Risk Assessment — HIGH/MEDIUM/LOW risk categorization with mitigation advice
* Missing Clause Detection — Identify absent standard clauses with suggested language
* Key Date Extraction — Extract all dates, deadlines, and time-sensitive obligations
* Contract Generator — Generate professional contracts from your requirements (14 types)
* Plain Language Summary — Non-lawyer friendly plain English summaries
* Analysis History — Full history stored in your database
* No API key config needed — managed entirely by AI Engine

**Supported AI Providers (via AI Engine):**
OpenAI (GPT-4o, GPT-4o Mini...), Anthropic (Claude Sonnet, Opus, Haiku...), Google (Gemini 1.5 Pro, Flash...), OpenRouter, Mistral, and more.

== Installation ==

1. Install and activate the AI Engine plugin: https://wordpress.org/plugins/ai-engine/
2. Configure your AI provider in AI Engine -> Settings
3. Upload `legal-ai-analyzer-aiengine` to `/wp-content/plugins/`
4. Activate the plugin
5. Go to Legal AI -> Dashboard or use shortcode [legal_ai_analyzer]

== Changelog ==

= 1.0.0 =
* Initial release — AI Engine powered version
